# Reference

**Parsed** endpoints return the typed payload and raise `ApiError` on a documented non-2xx. For the raw endpoints, see [Raw API Reference](raw-api-reference.md).

> Source: [GridWindowFlexPayApiClient](grid_window_flex_pay_api/client.py)

## AiApi

> Source: [AiApi](grid_window_flex_pay_api/apis/ai_api.py)

<details>
<summary><code>def ask_about_reservation(body: ApiAssistAskRequest | ApiAssistAskRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Ask a question about one of the caller's reservations.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.ai_api.ask_about_reservation(
        ApiAssistAskRequest(reservation_id="some example string", question="some example string")
    )
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type AskAboutReservationErrorBody
```

**Async**

```python
try:
    response = await async_client.ai_api.ask_about_reservation(
        ApiAssistAskRequest(reservation_id="some example string", question="some example string")
    )
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type AskAboutReservationErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAssistAskRequest](grid_window_flex_pay_api/models/api_assist_ask_request.py) \| [ApiAssistAskRequestDict](grid_window_flex_pay_api/models/api_assist_ask_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- Grounded answer and its source

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[AskAboutReservationErrorBody](grid_window_flex_pay_api/errors/ask_about_reservation_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def explain_offer(body: ApiAssistExplainRequest | ApiAssistExplainRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Numbers come from the stored quote; model text is checked against them before it is shown.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.ai_api.explain_offer(
        ApiAssistExplainRequest(quote_set_id="some example string", offer_id="some example string")
    )
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type ExplainOfferErrorBody
```

**Async**

```python
try:
    response = await async_client.ai_api.explain_offer(
        ApiAssistExplainRequest(quote_set_id="some example string", offer_id="some example string")
    )
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type ExplainOfferErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAssistExplainRequest](grid_window_flex_pay_api/models/api_assist_explain_request.py) \| [ApiAssistExplainRequestDict](grid_window_flex_pay_api/models/api_assist_explain_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- Explanation and its source

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[ExplainOfferErrorBody](grid_window_flex_pay_api/errors/explain_offer_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def parse_charging_request(body: ApiQuotesParseRequest | ApiQuotesParseRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ParseResult</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Fills a form only. It sets no price and approves nothing. Falls back to a labelled deterministic parser when no AI provider is available.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.ai_api.parse_charging_request(ApiQuotesParseRequest(text="some example string"))
    # TODO: Handle 'response' of type ParseResult
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type ParseChargingRequestErrorBody
```

**Async**

```python
try:
    response = await async_client.ai_api.parse_charging_request(ApiQuotesParseRequest(text="some example string"))
    # TODO: Handle 'response' of type ParseResult
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type ParseChargingRequestErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiQuotesParseRequest](grid_window_flex_pay_api/models/api_quotes_parse_request.py) \| [ApiQuotesParseRequestDict](grid_window_flex_pay_api/models/api_quotes_parse_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ParseResult](grid_window_flex_pay_api/models/parse_result.py)</code> -- Parsed fields and their source

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[ParseChargingRequestErrorBody](grid_window_flex_pay_api/errors/parse_charging_request_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 429 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def recommend_offer(body: ApiAgentDealsRequest | ApiAgentDealsRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> DealResult</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Read-only. It evaluates only offers the backend already priced and never accepts or pays.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.ai_api.recommend_offer(
        ApiAgentDealsRequest(quote_set_id="some example string", min_savings_cents=1, preference=Preference.LOWEST_COST)
    )
    # TODO: Handle 'response' of type DealResult
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RecommendOfferErrorBody
```

**Async**

```python
try:
    response = await async_client.ai_api.recommend_offer(
        ApiAgentDealsRequest(quote_set_id="some example string", min_savings_cents=1, preference=Preference.LOWEST_COST)
    )
    # TODO: Handle 'response' of type DealResult
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RecommendOfferErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAgentDealsRequest](grid_window_flex_pay_api/models/api_agent_deals_request.py) \| [ApiAgentDealsRequestDict](grid_window_flex_pay_api/models/api_agent_deals_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DealResult](grid_window_flex_pay_api/models/deal_result.py)</code> -- The recommendation and the evaluation behind it

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RecommendOfferErrorBody](grid_window_flex_pay_api/errors/recommend_offer_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404, 409 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

## Checkout

> Source: [Checkout](grid_window_flex_pay_api/apis/checkout.py)

<details>
<summary><code>def accept_offer(body: ApiOffersAcceptRequest | ApiOffersAcceptRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiOffersAcceptResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires the driver's explicit consent (`consent: true`) and the `termsHash` the driver saw; tampered or expired
terms are refused. Returns the PayPal approval link. Nothing is authorized or charged until the buyer approves in PayPal.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.checkout.accept_offer(
        ApiOffersAcceptRequest(
            quote_set_id="some example string", offer_id="some example string", terms_hash="some example string"
        ),
    )
    # TODO: Handle 'response' of type ApiOffersAcceptResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type AcceptOfferErrorBody
```

**Async**

```python
try:
    response = await async_client.checkout.accept_offer(
        ApiOffersAcceptRequest(
            quote_set_id="some example string", offer_id="some example string", terms_hash="some example string"
        ),
    )
    # TODO: Handle 'response' of type ApiOffersAcceptResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type AcceptOfferErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiOffersAcceptRequest](grid_window_flex_pay_api/models/api_offers_accept_request.py) \| [ApiOffersAcceptRequestDict](grid_window_flex_pay_api/models/api_offers_accept_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiOffersAcceptResponse](grid_window_flex_pay_api/models/api_offers_accept_response.py)</code> -- Reservation created, waiting for buyer approval

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[AcceptOfferErrorBody](grid_window_flex_pay_api/errors/accept_offer_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404, 409 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def checkout_cancel(rid: str, state: str, *, request_options: RequestOptionsOrDict | None = None) -> None</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

PayPal cancel URL. Cancels the pending order, then redirects to the reservation.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    client.checkout.checkout_cancel("some example string", "some example string")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    await async_client.checkout.checkout_cancel("some example string", "some example string")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>rid</code> | <code>str</code> | Value sent with the request. |
| <code>state</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: No content

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def checkout_return(rid: str, state: str, token: str, *, request_options: RequestOptionsOrDict | None = None) -> None</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

PayPal return URL. Authorizes the approved order, then redirects to the reservation.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    client.checkout.checkout_return("some example string", "some example string", "some example string")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    await async_client.checkout.checkout_return("some example string", "some example string", "some example string")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>rid</code> | <code>str</code> | Value sent with the request. |
| <code>state</code> | <code>str</code> | Signed anti-forgery state |
| <code>token</code> | <code>str</code> | PayPal order id |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: No content

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Offers

> Source: [Offers](grid_window_flex_pay_api/apis/offers.py)

<details>
<summary><code>def request_offers(body: QuoteRequest | QuoteRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiQuotesResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Creates the driver session cookie if absent. Each offer carries exact terms and their SHA-256 `termsHash`, which accept must echo.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.offers.request_offers(
        QuoteRequest(
            port_id="some example string",
            night_of="some example string",
            plug_in_local="some example string",
            depart_local="some example string",
            target_battery_k_wh=1.5,
            spend_cap_cents=1,
        ),
    )
    # TODO: Handle 'response' of type ApiQuotesResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RequestOffersErrorBody
```

**Async**

```python
try:
    response = await async_client.offers.request_offers(
        QuoteRequest(
            port_id="some example string",
            night_of="some example string",
            plug_in_local="some example string",
            depart_local="some example string",
            target_battery_k_wh=1.5,
            spend_cap_cents=1,
        ),
    )
    # TODO: Handle 'response' of type ApiQuotesResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RequestOffersErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[QuoteRequest](grid_window_flex_pay_api/models/quote_request.py) \| [QuoteRequestDict](grid_window_flex_pay_api/models/quote_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiQuotesResponse](grid_window_flex_pay_api/models/api_quotes_response.py)</code> -- The quote set

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RequestOffersErrorBody](grid_window_flex_pay_api/errors/request_offers_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 403, 409, 429 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

## Operator

> Source: [Operator](grid_window_flex_pay_api/apis/operator.py)

<details>
<summary><code>def get_operator_dashboard(*, night_of: str | None = None, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Every reservation of a night with load, ports and payment states.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.operator.get_operator_dashboard()
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetOperatorDashboardErrorBody
```

**Async**

```python
try:
    response = await async_client.operator.get_operator_dashboard()
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetOperatorDashboardErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>night_of</code> | <code>str \| None</code> | Value sent with the request.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- Dashboard data

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[GetOperatorDashboardErrorBody](grid_window_flex_pay_api/errors/get_operator_dashboard_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 401 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_operator_session(*, request_options: RequestOptionsOrDict | None = None) -> ApiOperatorSessionResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Whether the caller holds an operator session.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.operator.get_operator_session()
    # TODO: Handle 'response' of type ApiOperatorSessionResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.operator.get_operator_session()
    # TODO: Handle 'response' of type ApiOperatorSessionResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiOperatorSessionResponse](grid_window_flex_pay_api/models/api_operator_session_response.py)</code> -- Session state

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def operator_sign_in(body: ApiOperatorSessionRequest | ApiOperatorSessionRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> None</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Sign in with the operator passphrase.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    client.operator.operator_sign_in(ApiOperatorSessionRequest(passphrase="some example string"))
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type OperatorSignInErrorBody
```

**Async**

```python
try:
    await async_client.operator.operator_sign_in(ApiOperatorSessionRequest(passphrase="some example string"))
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type OperatorSignInErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiOperatorSessionRequest](grid_window_flex_pay_api/models/api_operator_session_request.py) \| [ApiOperatorSessionRequestDict](grid_window_flex_pay_api/models/api_operator_session_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: No content

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[OperatorSignInErrorBody](grid_window_flex_pay_api/errors/operator_sign_in_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 401 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def operator_sign_out(*, request_options: RequestOptionsOrDict | None = None) -> None</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Sign out.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    client.operator.operator_sign_out()
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    await async_client.operator.operator_sign_out()
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: No content

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Reservations

> Source: [Reservations](grid_window_flex_pay_api/apis/reservations.py)

<details>
<summary><code>def get_reservation(id_: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiReservationsResponse1</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

One reservation with payment state, provider proofs and receipt data.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.reservations.get_reservation("some example string")
    # TODO: Handle 'response' of type ApiReservationsResponse1
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetReservationErrorBody
```

**Async**

```python
try:
    response = await async_client.reservations.get_reservation("some example string")
    # TODO: Handle 'response' of type ApiReservationsResponse1
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetReservationErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiReservationsResponse1](grid_window_flex_pay_api/models/api_reservations_response1.py)</code> -- The reservation

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[GetReservationErrorBody](grid_window_flex_pay_api/errors/get_reservation_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def list_my_reservations(*, request_options: RequestOptionsOrDict | None = None) -> ApiReservationsResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Reservations made in the caller's driver session.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.reservations.list_my_reservations()
    # TODO: Handle 'response' of type ApiReservationsResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.reservations.list_my_reservations()
    # TODO: Handle 'response' of type ApiReservationsResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiReservationsResponse](grid_window_flex_pay_api/models/api_reservations_response.py)</code> -- The caller's reservations (empty without a session)

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Site

> Source: [Site](grid_window_flex_pay_api/apis/site.py)

<details>
<summary><code>def get_site_config(*, request_options: RequestOptionsOrDict | None = None) -> SiteConfig</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Station, ports, payment mode, AI status and the default charging window.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.site.get_site_config()
    # TODO: Handle 'response' of type SiteConfig
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.site.get_site_config()
    # TODO: Handle 'response' of type SiteConfig
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[SiteConfig](grid_window_flex_pay_api/models/site_config.py)</code> -- Site configuration

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Webhooks

> Source: [Webhooks](grid_window_flex_pay_api/apis/webhooks.py)

<details>
<summary><code>def paypal_webhook(body: Any, *, request_options: RequestOptionsOrDict | None = None) -> None</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Verifies the PayPal signature against the unaltered body, then re-reads provider state. A webhook alone never marks a payment captured or voided.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    client.webhooks.paypal_webhook({})
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type PaypalWebhookErrorBody
```

**Async**

```python
try:
    await async_client.webhooks.paypal_webhook({})
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type PaypalWebhookErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>Any</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: No content

**OnError**: <code>[ApiError](grid_window_flex_pay_api/core/exceptions.py)&#91;[PaypalWebhookErrorBody](grid_window_flex_pay_api/errors/paypal_webhook_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400 | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

