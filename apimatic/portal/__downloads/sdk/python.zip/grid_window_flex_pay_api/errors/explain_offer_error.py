from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

ExplainOfferErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _ExplainOfferError:
    def map(self, status_code: int, content: bytes) -> ExplainOfferErrorBody:
        match status_code:
            case 404:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


explain_offer_error_mapper: Final[ErrorMapper[ExplainOfferErrorBody]] = _ExplainOfferError()
