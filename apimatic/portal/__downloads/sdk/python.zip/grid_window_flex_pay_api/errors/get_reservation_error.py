from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

GetReservationErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _GetReservationError:
    def map(self, status_code: int, content: bytes) -> GetReservationErrorBody:
        match status_code:
            case 404:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


get_reservation_error_mapper: Final[ErrorMapper[GetReservationErrorBody]] = _GetReservationError()
