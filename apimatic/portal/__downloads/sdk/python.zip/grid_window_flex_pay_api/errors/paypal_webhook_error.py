from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

PaypalWebhookErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _PaypalWebhookError:
    def map(self, status_code: int, content: bytes) -> PaypalWebhookErrorBody:
        match status_code:
            case 400:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


paypal_webhook_error_mapper: Final[ErrorMapper[PaypalWebhookErrorBody]] = _PaypalWebhookError()
