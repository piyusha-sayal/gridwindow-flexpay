from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

AcceptOfferErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _AcceptOfferError:
    def map(self, status_code: int, content: bytes) -> AcceptOfferErrorBody:
        match status_code:
            case 404 | 409:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


accept_offer_error_mapper: Final[ErrorMapper[AcceptOfferErrorBody]] = _AcceptOfferError()
