from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

GetOperatorDashboardErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _GetOperatorDashboardError:
    def map(self, status_code: int, content: bytes) -> GetOperatorDashboardErrorBody:
        match status_code:
            case 401:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


get_operator_dashboard_error_mapper: Final[ErrorMapper[GetOperatorDashboardErrorBody]] = _GetOperatorDashboardError()
