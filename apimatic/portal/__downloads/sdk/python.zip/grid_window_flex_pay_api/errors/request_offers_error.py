from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

RequestOffersErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _RequestOffersError:
    def map(self, status_code: int, content: bytes) -> RequestOffersErrorBody:
        match status_code:
            case 400 | 403 | 409 | 429:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


request_offers_error_mapper: Final[ErrorMapper[RequestOffersErrorBody]] = _RequestOffersError()
