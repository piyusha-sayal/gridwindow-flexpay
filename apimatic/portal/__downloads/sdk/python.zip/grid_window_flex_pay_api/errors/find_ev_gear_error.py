from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

FindEvGearErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _FindEvGearError:
    def map(self, status_code: int, content: bytes) -> FindEvGearErrorBody:
        match status_code:
            case 429:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


find_ev_gear_error_mapper: Final[ErrorMapper[FindEvGearErrorBody]] = _FindEvGearError()
