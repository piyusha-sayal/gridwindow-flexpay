from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

RecommendOfferErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _RecommendOfferError:
    def map(self, status_code: int, content: bytes) -> RecommendOfferErrorBody:
        match status_code:
            case 404 | 409:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


recommend_offer_error_mapper: Final[ErrorMapper[RecommendOfferErrorBody]] = _RecommendOfferError()
