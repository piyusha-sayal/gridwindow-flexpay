from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

AskAboutReservationErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _AskAboutReservationError:
    def map(self, status_code: int, content: bytes) -> AskAboutReservationErrorBody:
        match status_code:
            case 404:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


ask_about_reservation_error_mapper: Final[ErrorMapper[AskAboutReservationErrorBody]] = _AskAboutReservationError()
