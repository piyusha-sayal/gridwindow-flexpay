from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel


class Item(SdkBaseModel):
    """One product"""

    id: Optional[str] = UNSET
    """Channel3 product id"""

    title: Optional[str] = UNSET
    """Product title"""

    brand: OptionalNullable[str] = UNSET
    """Brand name"""

    image_url: OptionalNullable[str] = Field(default=UNSET, alias="imageUrl")
    """Product image"""

    price_cents: Optional[int] = Field(default=UNSET, alias="priceCents")
    """Price in US cents"""

    compare_at_cents: OptionalNullable[int] = Field(default=UNSET, alias="compareAtCents")
    """Pre-discount price in cents"""

    currency: Optional[str] = UNSET
    """Currency code"""

    url: Optional[str] = UNSET
    """Merchant offer link"""

    domain: Optional[str] = UNSET
    """Merchant domain"""


class ItemDict(TypedDict):
    id: NotRequired[str]
    title: NotRequired[str]
    brand: NotRequired[str | None]
    image_url: NotRequired[str | None]
    price_cents: NotRequired[int]
    compare_at_cents: NotRequired[int | None]
    currency: NotRequired[str]
    url: NotRequired[str]
    domain: NotRequired[str]
