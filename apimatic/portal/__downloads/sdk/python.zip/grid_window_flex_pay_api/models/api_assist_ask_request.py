from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiAssistAskRequest(SdkBaseModel):
    reservation_id: str = Field(alias="reservationId")
    question: str


class ApiAssistAskRequestDict(TypedDict):
    reservation_id: str
    question: str
