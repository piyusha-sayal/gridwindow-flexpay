from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel
from .quote_set import QuoteSet, QuoteSetDict


class ApiQuotesResponse(SdkBaseModel):
    quote: QuoteSet


class ApiQuotesResponseDict(TypedDict):
    quote: QuoteSetDict
