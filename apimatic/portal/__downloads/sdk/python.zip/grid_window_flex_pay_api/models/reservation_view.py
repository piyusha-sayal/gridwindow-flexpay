from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .economics import Economics, EconomicsDict
from .enums.payment_state import PaymentStateOrStr
from .enums.provider_mode import ProviderModeOrStr
from .enums.service_state import ServiceStateOrStr
from .proof_view import ProofView, ProofViewDict


class ReservationView(SdkBaseModel):
    id: Optional[str] = UNSET
    provider_mode: Optional[ProviderModeOrStr] = Field(default=UNSET, alias="providerMode")
    payment_state: Optional[PaymentStateOrStr] = Field(default=UNSET, alias="paymentState")
    service_state: Optional[ServiceStateOrStr] = Field(default=UNSET, alias="serviceState")
    slots_committed: Optional[bool] = Field(default=UNSET, alias="slotsCommitted")
    port_label: Optional[str] = Field(default=UNSET, alias="portLabel")
    merchant_name: Optional[str] = Field(default=UNSET, alias="merchantName")
    time_zone: Optional[str] = Field(default=UNSET, alias="timeZone")
    plug_in_ms: Optional[int] = Field(default=UNSET, alias="plugInMs")
    depart_ms: Optional[int] = Field(default=UNSET, alias="departMs")
    target_battery_wh: Optional[int] = Field(default=UNSET, alias="targetBatteryWh")
    power_w: Optional[list[int]] = Field(default=UNSET, alias="powerW")
    terms_hash: Optional[str] = Field(default=UNSET, alias="termsHash")
    economics: Optional[Economics] = UNSET
    proofs: Optional[list[ProofView]] = UNSET


class ReservationViewDict(TypedDict):
    id: NotRequired[str]
    provider_mode: NotRequired[ProviderModeOrStr]
    payment_state: NotRequired[PaymentStateOrStr]
    service_state: NotRequired[ServiceStateOrStr]
    slots_committed: NotRequired[bool]
    port_label: NotRequired[str]
    merchant_name: NotRequired[str]
    time_zone: NotRequired[str]
    plug_in_ms: NotRequired[int]
    depart_ms: NotRequired[int]
    target_battery_wh: NotRequired[int]
    power_w: NotRequired[list[int]]
    terms_hash: NotRequired[str]
    economics: NotRequired[EconomicsDict]
    proofs: NotRequired[list[ProofViewDict]]
