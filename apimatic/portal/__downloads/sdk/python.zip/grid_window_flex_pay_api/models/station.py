from __future__ import annotations

from typing import Any

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Station(SdkBaseModel):
    name: Optional[str] = UNSET
    time_zone: Optional[str] = Field(default=UNSET, alias="timeZone")
    station_cap_w: Optional[int] = Field(default=UNSET, alias="stationCapW")
    ports: Optional[list[Any]] = UNSET


class StationDict(TypedDict):
    name: NotRequired[str]
    time_zone: NotRequired[str]
    station_cap_w: NotRequired[int]
    ports: NotRequired[list[Any]]
