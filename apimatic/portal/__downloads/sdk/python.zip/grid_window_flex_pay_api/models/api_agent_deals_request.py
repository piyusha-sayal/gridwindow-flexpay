from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel
from .enums.preference import PreferenceOrStr


class ApiAgentDealsRequest(SdkBaseModel):
    quote_set_id: str = Field(alias="quoteSetId")
    min_savings_cents: int | None = Field(alias="minSavingsCents")
    preference: PreferenceOrStr


class ApiAgentDealsRequestDict(TypedDict):
    quote_set_id: str
    min_savings_cents: int | None
    preference: PreferenceOrStr
