from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .item import Item, ItemDict


class ApiGearResponse(SdkBaseModel):
    """Gear search result"""

    enabled: Optional[bool] = UNSET
    """False when the server has no Channel3 key"""

    items: Optional[list[Item]] = UNSET
    """Products, cheapest in-stock offer each"""


class ApiGearResponseDict(TypedDict):
    enabled: NotRequired[bool]
    items: NotRequired[list[ItemDict]]
