from __future__ import annotations

from typing import Any

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel
from .priced_offer import PricedOffer, PricedOfferDict
from .rejected import Rejected, RejectedDict


class QuoteSet(SdkBaseModel):
    quote_set_id: Optional[str] = Field(default=UNSET, alias="quoteSetId")
    station_id: Optional[str] = Field(default=UNSET, alias="stationId")
    created_at_ms: Optional[int] = Field(default=UNSET, alias="createdAtMs")
    expires_at_ms: Optional[int] = Field(default=UNSET, alias="expiresAtMs")
    offers: Optional[list[PricedOffer]] = UNSET
    rejected: Optional[list[Rejected]] = UNSET
    baseline: Optional[Any] = UNSET
    """Immediate-charging comparison"""

    assumptions: Optional[Any] = UNSET
    """Tariff, economics and forecast labels; provenance is SYNTHETIC"""

    required_min_savings_cents: OptionalNullable[int] = Field(default=UNSET, alias="requiredMinSavingsCents")


class QuoteSetDict(TypedDict):
    quote_set_id: NotRequired[str]
    station_id: NotRequired[str]
    created_at_ms: NotRequired[int]
    expires_at_ms: NotRequired[int]
    offers: NotRequired[list[PricedOfferDict]]
    rejected: NotRequired[list[RejectedDict]]
    baseline: NotRequired[Any]
    assumptions: NotRequired[Any]
    required_min_savings_cents: NotRequired[int | None]
