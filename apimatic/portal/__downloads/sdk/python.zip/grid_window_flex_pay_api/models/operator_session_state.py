from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel


class OperatorSessionState(SdkBaseModel):
    operator: bool
    """Whether the caller holds an operator session after this call"""


class OperatorSessionStateDict(TypedDict):
    operator: bool
