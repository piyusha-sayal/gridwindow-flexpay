from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Rejected(SdkBaseModel):
    kind: Optional[str] = UNSET
    reason: Optional[str] = UNSET


class RejectedDict(TypedDict):
    kind: NotRequired[str]
    reason: NotRequired[str]
