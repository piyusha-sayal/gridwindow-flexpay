from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class QuoteRequest(SdkBaseModel):
    port_id: str = Field(alias="portId")
    night_of: str = Field(alias="nightOf")
    plug_in_local: str = Field(alias="plugInLocal")
    """Station-local time"""

    depart_local: str = Field(alias="departLocal")
    """Station-local ready-by time (next morning)"""

    target_battery_k_wh: float = Field(alias="targetBatteryKWh")
    """At most 2 decimals"""

    spend_cap_cents: int = Field(alias="spendCapCents")
    required_min_savings_cents: Optional[int] = Field(default=UNSET, alias="requiredMinSavingsCents")
    """Mandatory minimum saving versus immediate charging; accept refuses offers that save less"""


class QuoteRequestDict(TypedDict):
    port_id: str
    night_of: str
    plug_in_local: str
    depart_local: str
    target_battery_k_wh: float
    spend_cap_cents: int
    required_min_savings_cents: NotRequired[int]
