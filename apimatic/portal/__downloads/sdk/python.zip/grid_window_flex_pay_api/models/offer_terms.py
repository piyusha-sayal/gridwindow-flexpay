from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.currency import CurrencyOrStr


class OfferTerms(SdkBaseModel):
    """The exact agreement. ``termsHash`` is the SHA-256 of its canonical JSON."""

    version: Optional[str] = UNSET
    quote_set_id: Optional[str] = Field(default=UNSET, alias="quoteSetId")
    offer_id: Optional[str] = Field(default=UNSET, alias="offerId")
    station_id: Optional[str] = Field(default=UNSET, alias="stationId")
    merchant_ref: Optional[str] = Field(default=UNSET, alias="merchantRef")
    port_id: Optional[str] = Field(default=UNSET, alias="portId")
    currency: Optional[CurrencyOrStr] = UNSET
    amount_cents: Optional[int] = Field(default=UNSET, alias="amountCents")
    list_price_cents: Optional[int] = Field(default=UNSET, alias="listPriceCents")
    target_battery_wh: Optional[int] = Field(default=UNSET, alias="targetBatteryWh")
    plug_in_ms: Optional[int] = Field(default=UNSET, alias="plugInMs")
    depart_ms: Optional[int] = Field(default=UNSET, alias="departMs")
    grid_start_ms: Optional[int] = Field(default=UNSET, alias="gridStartMs")
    power_w: Optional[list[int]] = Field(default=UNSET, alias="powerW")
    """Planned charging power per quarter-hour slot"""

    expires_at_ms: Optional[int] = Field(default=UNSET, alias="expiresAtMs")


class OfferTermsDict(TypedDict):
    version: NotRequired[str]
    quote_set_id: NotRequired[str]
    offer_id: NotRequired[str]
    station_id: NotRequired[str]
    merchant_ref: NotRequired[str]
    port_id: NotRequired[str]
    currency: NotRequired[CurrencyOrStr]
    amount_cents: NotRequired[int]
    list_price_cents: NotRequired[int]
    target_battery_wh: NotRequired[int]
    plug_in_ms: NotRequired[int]
    depart_ms: NotRequired[int]
    grid_start_ms: NotRequired[int]
    power_w: NotRequired[list[int]]
    expires_at_ms: NotRequired[int]
