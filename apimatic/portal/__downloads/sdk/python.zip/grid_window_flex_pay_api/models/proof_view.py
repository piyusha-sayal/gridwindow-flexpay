from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ProofView(SdkBaseModel):
    """Provider evidence read back from PayPal (or MOCK) before any paid or voided label"""

    type_: Optional[str] = Field(default=UNSET, alias="type")
    ref: Optional[str] = UNSET
    status: Optional[str] = UNSET
    amount_cents: Optional[int] = Field(default=UNSET, alias="amountCents")


class ProofViewDict(TypedDict):
    type_: NotRequired[str]
    ref: NotRequired[str]
    status: NotRequired[str]
    amount_cents: NotRequired[int]
