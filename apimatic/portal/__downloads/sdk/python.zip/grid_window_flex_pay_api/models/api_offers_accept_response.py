from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel
from .enums.provider_mode import ProviderModeOrStr


class ApiOffersAcceptResponse(SdkBaseModel):
    reservation_id: str = Field(alias="reservationId")
    approve_url: str = Field(alias="approveUrl")
    """PayPal Sandbox checkout URL, or the in-app MOCK approval page"""

    provider_mode: ProviderModeOrStr = Field(alias="providerMode")


class ApiOffersAcceptResponseDict(TypedDict):
    reservation_id: str
    approve_url: str
    provider_mode: ProviderModeOrStr
