from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Error1(SdkBaseModel):
    code: str
    message: str
    fields: Optional[list[str]] = UNSET


class Error1Dict(TypedDict):
    code: str
    message: str
    fields: NotRequired[list[str]]
