from __future__ import annotations

from typing import Any

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .evaluation import Evaluation, EvaluationDict


class DealResult(SdkBaseModel):
    evaluation: Optional[Evaluation] = UNSET
    source: Optional[Any] = UNSET
    """Which model or the deterministic fallback produced the narrative"""


class DealResultDict(TypedDict):
    evaluation: NotRequired[EvaluationDict]
    source: NotRequired[Any]
