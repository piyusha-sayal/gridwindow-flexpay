from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.ai_source_kind import AiSourceKindOrStr
from .evaluation import Evaluation, EvaluationDict


class DealResult(SdkBaseModel):
    evaluation: Optional[Evaluation] = UNSET
    summary: Optional[str] = UNSET
    """Plain-language recommendation; every figure comes from the server-priced quote"""

    points: Optional[list[str]] = UNSET
    source: Optional[AiSourceKindOrStr] = UNSET
    """Which produced the text. A deterministic fallback is never presented as a model answer."""

    model: Optional[str] = UNSET
    """Model that wrote the narrative (present when source is MODEL)"""

    reason: Optional[str] = UNSET
    """Why the deterministic fallback answered (present when source is DETERMINISTIC_FALLBACK)"""


class DealResultDict(TypedDict):
    evaluation: NotRequired[EvaluationDict]
    summary: NotRequired[str]
    points: NotRequired[list[str]]
    source: NotRequired[AiSourceKindOrStr]
    model: NotRequired[str]
    reason: NotRequired[str]
