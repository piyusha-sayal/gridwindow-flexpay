from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel


class Ai(SdkBaseModel):
    enabled: Optional[bool] = UNSET
    model: OptionalNullable[str] = UNSET


class AiDict(TypedDict):
    enabled: NotRequired[bool]
    model: NotRequired[str | None]
