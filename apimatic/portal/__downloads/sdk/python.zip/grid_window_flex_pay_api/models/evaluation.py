from __future__ import annotations

from typing import Any

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel


class Evaluation(SdkBaseModel):
    status: Optional[str] = UNSET
    recommended_offer_id: OptionalNullable[str] = Field(default=UNSET, alias="recommendedOfferId")
    candidates: Optional[list[Any]] = UNSET
    backend_rejected: Optional[list[Any]] = Field(default=UNSET, alias="backendRejected")


class EvaluationDict(TypedDict):
    status: NotRequired[str]
    recommended_offer_id: NotRequired[str | None]
    candidates: NotRequired[list[Any]]
    backend_rejected: NotRequired[list[Any]]
