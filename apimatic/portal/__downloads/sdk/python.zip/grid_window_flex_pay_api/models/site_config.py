from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Date, Optional, SdkBaseModel
from .ai import Ai, AiDict
from .enums.provider_mode import ProviderModeOrStr
from .station import Station, StationDict


class SiteConfig(SdkBaseModel):
    provider_mode: Optional[ProviderModeOrStr] = Field(default=UNSET, alias="providerMode")
    station: Optional[Station] = UNSET
    ai: Optional[Ai] = UNSET
    default_night_of: Optional[Date] = Field(default=UNSET, alias="defaultNightOf")
    default_plug_in_local: Optional[str] = Field(default=UNSET, alias="defaultPlugInLocal")
    default_depart_local: Optional[str] = Field(default=UNSET, alias="defaultDepartLocal")


class SiteConfigDict(TypedDict):
    provider_mode: NotRequired[ProviderModeOrStr]
    station: NotRequired[StationDict]
    ai: NotRequired[AiDict]
    default_night_of: NotRequired[Date]
    default_plug_in_local: NotRequired[str]
    default_depart_local: NotRequired[str]
