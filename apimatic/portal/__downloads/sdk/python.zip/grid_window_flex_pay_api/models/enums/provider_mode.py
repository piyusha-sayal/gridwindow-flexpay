from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class ProviderMode(str, Enum):
    PAYPAL_SANDBOX = "PAYPAL_SANDBOX"
    MOCK = "MOCK"

    __str__ = str.__str__


ProviderModeOrStr: TypeAlias = Annotated[ProviderMode | str, open_enum_validator(ProviderMode)]
