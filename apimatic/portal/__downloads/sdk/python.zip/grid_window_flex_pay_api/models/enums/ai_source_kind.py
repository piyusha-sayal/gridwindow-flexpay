from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class AiSourceKind(str, Enum):
    """Which produced the text. A deterministic fallback is never presented as a model answer."""

    MODEL = "MODEL"
    DETERMINISTIC_FALLBACK = "DETERMINISTIC_FALLBACK"

    __str__ = str.__str__


AiSourceKindOrStr: TypeAlias = Annotated[AiSourceKind | str, open_enum_validator(AiSourceKind)]
