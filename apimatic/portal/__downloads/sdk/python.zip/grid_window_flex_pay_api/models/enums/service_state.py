from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class ServiceState(str, Enum):
    AWAITING_PAYMENT = "AWAITING_PAYMENT"
    SCHEDULED = "SCHEDULED"
    DELIVERED = "DELIVERED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

    __str__ = str.__str__


ServiceStateOrStr: TypeAlias = Annotated[ServiceState | str, open_enum_validator(ServiceState)]
