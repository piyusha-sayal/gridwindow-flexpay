from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class Kind(str, Enum):
    FLEX_LOWEST_COST = "flex_lowest_cost"
    FLEX_EARLY_FINISH = "flex_early_finish"
    FLEX_GENTLE = "flex_gentle"

    __str__ = str.__str__


KindOrStr: TypeAlias = Annotated[Kind | str, open_enum_validator(Kind)]
