from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class Preference(str, Enum):
    LOWEST_COST = "lowest_cost"
    EARLY_FINISH = "early_finish"
    GENTLE = "gentle"

    __str__ = str.__str__


PreferenceOrStr: TypeAlias = Annotated[Preference | str, open_enum_validator(Preference)]
