from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class PaymentState(str, Enum):
    QUOTE_ACCEPTED = "QUOTE_ACCEPTED"
    ORDER_CREATED = "ORDER_CREATED"
    BUYER_APPROVED = "BUYER_APPROVED"
    AUTHORIZED = "AUTHORIZED"
    CAPTURE_PENDING = "CAPTURE_PENDING"
    CAPTURED = "CAPTURED"
    CAPTURE_DECLINED = "CAPTURE_DECLINED"
    VOIDED = "VOIDED"
    CANCELLED = "CANCELLED"
    FAILED = "FAILED"
    NEEDS_RECONCILIATION = "NEEDS_RECONCILIATION"

    __str__ = str.__str__


PaymentStateOrStr: TypeAlias = Annotated[PaymentState | str, open_enum_validator(PaymentState)]
