from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.ai_source_kind import AiSourceKindOrStr


class AskResult(SdkBaseModel):
    answer: str
    in_scope: bool = Field(alias="inScope")
    """False when the question is outside what the assistant may answer"""

    source: AiSourceKindOrStr
    """Which produced the text. A deterministic fallback is never presented as a model answer."""

    model: Optional[str] = UNSET
    reason: Optional[str] = UNSET


class AskResultDict(TypedDict):
    answer: str
    in_scope: bool
    source: AiSourceKindOrStr
    model: NotRequired[str]
    reason: NotRequired[str]
