from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiAssistExplainRequest(SdkBaseModel):
    quote_set_id: str = Field(alias="quoteSetId")
    offer_id: str = Field(alias="offerId")


class ApiAssistExplainRequestDict(TypedDict):
    quote_set_id: str
    offer_id: str
