from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel


class Economics(SdkBaseModel):
    list_price_cents: Optional[int] = Field(default=UNSET, alias="listPriceCents")
    price_cents: Optional[int] = Field(default=UNSET, alias="priceCents")
    discount_cents: Optional[int] = Field(default=UNSET, alias="discountCents")
    energy_cost_cents: Optional[int] = Field(default=UNSET, alias="energyCostCents")
    baseline_energy_cost_cents: OptionalNullable[int] = Field(default=UNSET, alias="baselineEnergyCostCents")
    operator_improvement_cents: Optional[int] = Field(default=UNSET, alias="operatorImprovementCents")


class EconomicsDict(TypedDict):
    list_price_cents: NotRequired[int]
    price_cents: NotRequired[int]
    discount_cents: NotRequired[int]
    energy_cost_cents: NotRequired[int]
    baseline_energy_cost_cents: NotRequired[int | None]
    operator_improvement_cents: NotRequired[int]
