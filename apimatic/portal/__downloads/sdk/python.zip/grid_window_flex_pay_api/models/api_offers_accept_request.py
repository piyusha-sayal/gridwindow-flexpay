from __future__ import annotations

from typing import Literal

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiOffersAcceptRequest(SdkBaseModel):
    quote_set_id: str = Field(alias="quoteSetId")
    offer_id: str = Field(alias="offerId")
    terms_hash: str = Field(alias="termsHash")
    consent: Literal["True"] = "True"


class ApiOffersAcceptRequestDict(TypedDict):
    quote_set_id: str
    offer_id: str
    terms_hash: str
    consent: Literal["True"]
