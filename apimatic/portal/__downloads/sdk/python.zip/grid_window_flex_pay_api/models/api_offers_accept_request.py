from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiOffersAcceptRequest(SdkBaseModel):
    quote_set_id: str = Field(alias="quoteSetId")
    offer_id: str = Field(alias="offerId")
    terms_hash: str = Field(alias="termsHash")
    consent: bool
    """Must be ``true`` (the driver's explicit consent to these exact terms); any other value is refused."""


class ApiOffersAcceptRequestDict(TypedDict):
    quote_set_id: str
    offer_id: str
    terms_hash: str
    consent: bool
