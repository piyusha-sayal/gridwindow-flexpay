from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiQuotesParseRequest(SdkBaseModel):
    text: str


class ApiQuotesParseRequestDict(TypedDict):
    text: str
