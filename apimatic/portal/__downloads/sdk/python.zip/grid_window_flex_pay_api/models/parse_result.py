from __future__ import annotations

from typing import Any

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ParseResult(SdkBaseModel):
    parsed: Optional[Any] = UNSET
    """Fields to pre-fill: targetBatteryKWh, departLocal, minSavingsCents, preference, notes"""

    source: Optional[str] = UNSET
    reason: Optional[str] = UNSET


class ParseResultDict(TypedDict):
    parsed: NotRequired[Any]
    source: NotRequired[str]
    reason: NotRequired[str]
