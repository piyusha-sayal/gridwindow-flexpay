from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .reservation_view import ReservationView, ReservationViewDict


class ApiReservationsResponse(SdkBaseModel):
    reservations: Optional[list[ReservationView]] = UNSET


class ApiReservationsResponseDict(TypedDict):
    reservations: NotRequired[list[ReservationViewDict]]
