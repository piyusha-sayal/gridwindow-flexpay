from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.ai_source_kind import AiSourceKindOrStr


class ExplainResult(SdkBaseModel):
    summary: str
    points: list[str]
    source: AiSourceKindOrStr
    """Which produced the text. A deterministic fallback is never presented as a model answer."""

    model: Optional[str] = UNSET
    reason: Optional[str] = UNSET


class ExplainResultDict(TypedDict):
    summary: str
    points: list[str]
    source: AiSourceKindOrStr
    model: NotRequired[str]
    reason: NotRequired[str]
