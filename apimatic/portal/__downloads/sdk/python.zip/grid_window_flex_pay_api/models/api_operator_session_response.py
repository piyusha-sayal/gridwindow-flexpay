from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiOperatorSessionResponse(SdkBaseModel):
    operator: Optional[bool] = UNSET


class ApiOperatorSessionResponseDict(TypedDict):
    operator: NotRequired[bool]
