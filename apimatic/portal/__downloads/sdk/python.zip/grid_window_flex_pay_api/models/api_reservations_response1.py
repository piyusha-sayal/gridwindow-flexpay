from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .reservation_view import ReservationView, ReservationViewDict


class ApiReservationsResponse1(SdkBaseModel):
    reservation: Optional[ReservationView] = UNSET


class ApiReservationsResponse1Dict(TypedDict):
    reservation: NotRequired[ReservationViewDict]
