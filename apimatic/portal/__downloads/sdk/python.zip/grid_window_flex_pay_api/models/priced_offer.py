from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.kind import KindOrStr
from .offer_terms import OfferTerms, OfferTermsDict


class PricedOffer(SdkBaseModel):
    offer_id: Optional[str] = Field(default=UNSET, alias="offerId")
    kind: Optional[KindOrStr] = UNSET
    label: Optional[str] = UNSET
    charge_start_ms: Optional[int] = Field(default=UNSET, alias="chargeStartMs")
    charge_end_ms: Optional[int] = Field(default=UNSET, alias="chargeEndMs")
    list_price_cents: Optional[int] = Field(default=UNSET, alias="listPriceCents")
    price_cents: Optional[int] = Field(default=UNSET, alias="priceCents")
    discount_cents: Optional[int] = Field(default=UNSET, alias="discountCents")
    energy_cost_cents: Optional[int] = Field(default=UNSET, alias="energyCostCents")
    operator_improvement_cents: Optional[int] = Field(default=UNSET, alias="operatorImprovementCents")
    power_w: Optional[list[int]] = Field(default=UNSET, alias="powerW")
    terms: Optional[OfferTerms] = UNSET
    """The exact agreement. ``termsHash`` is the SHA-256 of its canonical JSON."""

    terms_hash: Optional[str] = Field(default=UNSET, alias="termsHash")


class PricedOfferDict(TypedDict):
    offer_id: NotRequired[str]
    kind: NotRequired[KindOrStr]
    label: NotRequired[str]
    charge_start_ms: NotRequired[int]
    charge_end_ms: NotRequired[int]
    list_price_cents: NotRequired[int]
    price_cents: NotRequired[int]
    discount_cents: NotRequired[int]
    energy_cost_cents: NotRequired[int]
    operator_improvement_cents: NotRequired[int]
    power_w: NotRequired[list[int]]
    terms: NotRequired[OfferTermsDict]
    terms_hash: NotRequired[str]
