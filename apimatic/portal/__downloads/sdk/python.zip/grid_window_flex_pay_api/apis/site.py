from __future__ import annotations

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    async_json_decoder,
    json_decoder,
    raw_error_response,
    unwrap,
)
from ..models.site_config import SiteConfig
from ..server.server import Server


class Site:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = SiteWithRawResponse(client, server)

    def get_site_config(self, *, request_options: RequestOptionsOrDict | None = None) -> SiteConfig:
        """Station, ports, payment mode, AI status and the default charging window.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Site configuration

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.get_site_config(request_options=request_options))

    @property
    def with_raw_response(self) -> SiteWithRawResponse:
        return self._with_raw_response


class AsyncSite:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncSiteWithRawResponse(client, server)

    async def get_site_config(self, *, request_options: RequestOptionsOrDict | None = None) -> SiteConfig:
        """Station, ports, payment mode, AI status and the default charging window.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Site configuration

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.get_site_config(request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncSiteWithRawResponse:
        return self._with_raw_response


class SiteWithRawResponse(BaseRawResponse[RawClient, Server]):
    def get_site_config(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[SiteConfig, RawError]:
        """Station, ports, payment mode, AI status and the default charging window.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/config"),
            decoder=json_decoder[SiteConfig],
            error_mapper=raw_error_response,
            request_options=request_options,
        )


class AsyncSiteWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def get_site_config(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[SiteConfig, RawError]:
        """Station, ports, payment mode, AI status and the default charging window.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/config"),
            decoder=async_json_decoder[SiteConfig],
            error_mapper=raw_error_response,
            request_options=request_options,
        )
