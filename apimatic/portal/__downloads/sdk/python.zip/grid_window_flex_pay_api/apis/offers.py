from __future__ import annotations

from uuid import UUID, uuid4

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RequestOptionsOrDict,
    async_json_decoder,
    json_body,
    json_decoder,
    param,
    unwrap,
)
from ..errors.request_offers_error import RequestOffersErrorBody, request_offers_error_mapper
from ..models.api_quotes_response import ApiQuotesResponse
from ..models.quote_request import QuoteRequest, QuoteRequestDict
from ..server.server import Server


class Offers:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = OffersWithRawResponse(client, server)

    def request_offers(
        self, body: QuoteRequest | QuoteRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiQuotesResponse:
        """Creates the driver session cookie if absent. Each offer carries exact terms and their SHA-256 ``termsHash``,
        which accept must echo.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The quote set

        Raises:
            ApiError: Invalid input Request origin not allowed The request conflicts with current state (expired offer,
                terms mismatch, already accepted, ...) Too many requests ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.request_offers(body, request_options=request_options))

    @property
    def with_raw_response(self) -> OffersWithRawResponse:
        return self._with_raw_response


class AsyncOffers:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncOffersWithRawResponse(client, server)

    async def request_offers(
        self, body: QuoteRequest | QuoteRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiQuotesResponse:
        """Creates the driver session cookie if absent. Each offer carries exact terms and their SHA-256 ``termsHash``,
        which accept must echo.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The quote set

        Raises:
            ApiError: Invalid input Request origin not allowed The request conflicts with current state (expired offer,
                terms mismatch, already accepted, ...) Too many requests ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.request_offers(body, request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncOffersWithRawResponse:
        return self._with_raw_response


class OffersWithRawResponse(BaseRawResponse[RawClient, Server]):
    def request_offers(
        self, body: QuoteRequest | QuoteRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiQuotesResponse, RequestOffersErrorBody]:
        """Creates the driver session cookie if absent. Each offer carries exact terms and their SHA-256 ``termsHash``,
        which accept must echo.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/quotes"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[QuoteRequest | QuoteRequestDict](body),
            decoder=json_decoder[ApiQuotesResponse],
            error_mapper=request_offers_error_mapper,
            request_options=request_options,
        )


class AsyncOffersWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def request_offers(
        self, body: QuoteRequest | QuoteRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiQuotesResponse, RequestOffersErrorBody]:
        """Creates the driver session cookie if absent. Each offer carries exact terms and their SHA-256 ``termsHash``,
        which accept must echo.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/quotes"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[QuoteRequest | QuoteRequestDict](body),
            decoder=async_json_decoder[ApiQuotesResponse],
            error_mapper=request_offers_error_mapper,
            request_options=request_options,
        )
