from __future__ import annotations

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RequestOptionsOrDict,
    async_json_decoder,
    json_decoder,
    param,
    unwrap,
)
from ..errors.find_ev_gear_error import FindEvGearErrorBody, find_ev_gear_error_mapper
from ..models.api_gear_response import ApiGearResponse
from ..server.server import Server


class Gear:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = GearWithRawResponse(client, server)

    def find_ev_gear(
        self,
        *,
        q: str | None = None,
        max_price_cents: int | None = None,
        limit: int | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiGearResponse:
        """Read-only product search through Channel3. Returns merchant links; nothing is bought. ``enabled`` is false
        when no Channel3 key is configured on the server.

        Args:
            q: Search text; defaults to common EV charging accessories.
            max_price_cents: Price cap in US cents.
            limit: Number of results (1-12).
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Search result

        Raises:
            ApiError: Too many requests ``error`` is ``Error | RawError``."""
        return unwrap(
            self._with_raw_response.find_ev_gear(
                q=q, max_price_cents=max_price_cents, limit=limit, request_options=request_options
            ),
        )

    @property
    def with_raw_response(self) -> GearWithRawResponse:
        return self._with_raw_response


class AsyncGear:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncGearWithRawResponse(client, server)

    async def find_ev_gear(
        self,
        *,
        q: str | None = None,
        max_price_cents: int | None = None,
        limit: int | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiGearResponse:
        """Read-only product search through Channel3. Returns merchant links; nothing is bought. ``enabled`` is false
        when no Channel3 key is configured on the server.

        Args:
            q: Search text; defaults to common EV charging accessories.
            max_price_cents: Price cap in US cents.
            limit: Number of results (1-12).
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Search result

        Raises:
            ApiError: Too many requests ``error`` is ``Error | RawError``."""
        return unwrap(
            await self._with_raw_response.find_ev_gear(
                q=q, max_price_cents=max_price_cents, limit=limit, request_options=request_options
            ),
        )

    @property
    def with_raw_response(self) -> AsyncGearWithRawResponse:
        return self._with_raw_response


class GearWithRawResponse(BaseRawResponse[RawClient, Server]):
    def find_ev_gear(
        self,
        *,
        q: str | None = None,
        max_price_cents: int | None = None,
        limit: int | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiGearResponse, FindEvGearErrorBody]:
        """Read-only product search through Channel3. Returns merchant links; nothing is bought. ``enabled`` is false
        when no Channel3 key is configured on the server.

        Args:
            q: Search text; defaults to common EV charging accessories.
            max_price_cents: Price cap in US cents.
            limit: Number of results (1-12).
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/gear"),
            query_params=[
                param[str | None]("q", q),
                param[int | None]("maxPriceCents", max_price_cents),
                param[int | None]("limit", limit),
            ],
            decoder=json_decoder[ApiGearResponse],
            error_mapper=find_ev_gear_error_mapper,
            request_options=request_options,
        )


class AsyncGearWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def find_ev_gear(
        self,
        *,
        q: str | None = None,
        max_price_cents: int | None = None,
        limit: int | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiGearResponse, FindEvGearErrorBody]:
        """Read-only product search through Channel3. Returns merchant links; nothing is bought. ``enabled`` is false
        when no Channel3 key is configured on the server.

        Args:
            q: Search text; defaults to common EV charging accessories.
            max_price_cents: Price cap in US cents.
            limit: Number of results (1-12).
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/gear"),
            query_params=[
                param[str | None]("q", q),
                param[int | None]("maxPriceCents", max_price_cents),
                param[int | None]("limit", limit),
            ],
            decoder=async_json_decoder[ApiGearResponse],
            error_mapper=find_ev_gear_error_mapper,
            request_options=request_options,
        )
