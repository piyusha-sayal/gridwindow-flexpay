from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RequestOptionsOrDict,
    async_empty_response,
    empty_response,
    json_body,
    param,
    unwrap,
)
from ..errors.paypal_webhook_error import PaypalWebhookErrorBody, paypal_webhook_error_mapper
from ..server.server import Server


class Webhooks:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = WebhooksWithRawResponse(client, server)

    def paypal_webhook(self, body: Any, *, request_options: RequestOptionsOrDict | None = None) -> None:
        """Verifies the PayPal signature against the unaltered body, then re-reads provider state. A webhook alone never
        marks a payment captured or voided.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Accepted

        Raises:
            ApiError: Signature verification failed ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.paypal_webhook(body, request_options=request_options))

    @property
    def with_raw_response(self) -> WebhooksWithRawResponse:
        return self._with_raw_response


class AsyncWebhooks:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncWebhooksWithRawResponse(client, server)

    async def paypal_webhook(self, body: Any, *, request_options: RequestOptionsOrDict | None = None) -> None:
        """Verifies the PayPal signature against the unaltered body, then re-reads provider state. A webhook alone never
        marks a payment captured or voided.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Accepted

        Raises:
            ApiError: Signature verification failed ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.paypal_webhook(body, request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncWebhooksWithRawResponse:
        return self._with_raw_response


class WebhooksWithRawResponse(BaseRawResponse[RawClient, Server]):
    def paypal_webhook(
        self, body: Any, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, PaypalWebhookErrorBody]:
        """Verifies the PayPal signature against the unaltered body, then re-reads provider state. A webhook alone never
        marks a payment captured or voided.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/webhooks/paypal"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[Any](body),
            decoder=empty_response,
            error_mapper=paypal_webhook_error_mapper,
            request_options=request_options,
        )


class AsyncWebhooksWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def paypal_webhook(
        self, body: Any, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, PaypalWebhookErrorBody]:
        """Verifies the PayPal signature against the unaltered body, then re-reads provider state. A webhook alone never
        marks a payment captured or voided.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/webhooks/paypal"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[Any](body),
            decoder=async_empty_response,
            error_mapper=paypal_webhook_error_mapper,
            request_options=request_options,
        )
