from __future__ import annotations

from uuid import UUID, uuid4

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RequestOptionsOrDict,
    async_json_decoder,
    json_body,
    json_decoder,
    param,
    unwrap,
)
from ..errors.ask_about_reservation_error import AskAboutReservationErrorBody, ask_about_reservation_error_mapper
from ..errors.explain_offer_error import ExplainOfferErrorBody, explain_offer_error_mapper
from ..errors.parse_charging_request_error import ParseChargingRequestErrorBody, parse_charging_request_error_mapper
from ..errors.recommend_offer_error import RecommendOfferErrorBody, recommend_offer_error_mapper
from ..models.api_agent_deals_request import ApiAgentDealsRequest, ApiAgentDealsRequestDict
from ..models.api_assist_ask_request import ApiAssistAskRequest, ApiAssistAskRequestDict
from ..models.api_assist_explain_request import ApiAssistExplainRequest, ApiAssistExplainRequestDict
from ..models.api_quotes_parse_request import ApiQuotesParseRequest, ApiQuotesParseRequestDict
from ..models.ask_result import AskResult
from ..models.deal_result import DealResult
from ..models.explain_result import ExplainResult
from ..models.parse_result import ParseResult
from ..server.server import Server


class AiApi:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = AiApiWithRawResponse(client, server)

    def ask_about_reservation(
        self,
        body: ApiAssistAskRequest | ApiAssistAskRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> AskResult:
        """Ask a question about one of the caller's reservations.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Grounded answer and its source

        Raises:
            ApiError: Not found (or not the caller's) ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.ask_about_reservation(body, request_options=request_options))

    def explain_offer(
        self,
        body: ApiAssistExplainRequest | ApiAssistExplainRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ExplainResult:
        """Numbers come from the stored quote; model text is checked against them before it is shown.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Explanation and its source

        Raises:
            ApiError: Not found (or not the caller's) ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.explain_offer(body, request_options=request_options))

    def parse_charging_request(
        self,
        body: ApiQuotesParseRequest | ApiQuotesParseRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ParseResult:
        """Fills a form only. It sets no price and approves nothing. Falls back to a labelled deterministic parser when
        no AI provider is available.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Parsed fields and their source

        Raises:
            ApiError: Invalid input Too many requests ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.parse_charging_request(body, request_options=request_options))

    def recommend_offer(
        self,
        body: ApiAgentDealsRequest | ApiAgentDealsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> DealResult:
        """Read-only. It evaluates only offers the backend already priced and never accepts or pays.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The recommendation and the evaluation behind it

        Raises:
            ApiError: Not found (or not the caller's) The request conflicts with current state (expired offer, terms
                mismatch, already accepted, ...) ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.recommend_offer(body, request_options=request_options))

    @property
    def with_raw_response(self) -> AiApiWithRawResponse:
        return self._with_raw_response


class AsyncAiApi:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncAiApiWithRawResponse(client, server)

    async def ask_about_reservation(
        self,
        body: ApiAssistAskRequest | ApiAssistAskRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> AskResult:
        """Ask a question about one of the caller's reservations.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Grounded answer and its source

        Raises:
            ApiError: Not found (or not the caller's) ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.ask_about_reservation(body, request_options=request_options))

    async def explain_offer(
        self,
        body: ApiAssistExplainRequest | ApiAssistExplainRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ExplainResult:
        """Numbers come from the stored quote; model text is checked against them before it is shown.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Explanation and its source

        Raises:
            ApiError: Not found (or not the caller's) ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.explain_offer(body, request_options=request_options))

    async def parse_charging_request(
        self,
        body: ApiQuotesParseRequest | ApiQuotesParseRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ParseResult:
        """Fills a form only. It sets no price and approves nothing. Falls back to a labelled deterministic parser when
        no AI provider is available.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Parsed fields and their source

        Raises:
            ApiError: Invalid input Too many requests ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.parse_charging_request(body, request_options=request_options))

    async def recommend_offer(
        self,
        body: ApiAgentDealsRequest | ApiAgentDealsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> DealResult:
        """Read-only. It evaluates only offers the backend already priced and never accepts or pays.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The recommendation and the evaluation behind it

        Raises:
            ApiError: Not found (or not the caller's) The request conflicts with current state (expired offer, terms
                mismatch, already accepted, ...) ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.recommend_offer(body, request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncAiApiWithRawResponse:
        return self._with_raw_response


class AiApiWithRawResponse(BaseRawResponse[RawClient, Server]):
    def ask_about_reservation(
        self,
        body: ApiAssistAskRequest | ApiAssistAskRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[AskResult, AskAboutReservationErrorBody]:
        """Ask a question about one of the caller's reservations.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/assist/ask"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAssistAskRequest | ApiAssistAskRequestDict](body),
            decoder=json_decoder[AskResult],
            error_mapper=ask_about_reservation_error_mapper,
            request_options=request_options,
        )

    def explain_offer(
        self,
        body: ApiAssistExplainRequest | ApiAssistExplainRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ExplainResult, ExplainOfferErrorBody]:
        """Numbers come from the stored quote; model text is checked against them before it is shown.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/assist/explain"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAssistExplainRequest | ApiAssistExplainRequestDict](body),
            decoder=json_decoder[ExplainResult],
            error_mapper=explain_offer_error_mapper,
            request_options=request_options,
        )

    def parse_charging_request(
        self,
        body: ApiQuotesParseRequest | ApiQuotesParseRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ParseResult, ParseChargingRequestErrorBody]:
        """Fills a form only. It sets no price and approves nothing. Falls back to a labelled deterministic parser when
        no AI provider is available.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/quotes/parse"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiQuotesParseRequest | ApiQuotesParseRequestDict](body),
            decoder=json_decoder[ParseResult],
            error_mapper=parse_charging_request_error_mapper,
            request_options=request_options,
        )

    def recommend_offer(
        self,
        body: ApiAgentDealsRequest | ApiAgentDealsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[DealResult, RecommendOfferErrorBody]:
        """Read-only. It evaluates only offers the backend already priced and never accepts or pays.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/agent/deals"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAgentDealsRequest | ApiAgentDealsRequestDict](body),
            decoder=json_decoder[DealResult],
            error_mapper=recommend_offer_error_mapper,
            request_options=request_options,
        )


class AsyncAiApiWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def ask_about_reservation(
        self,
        body: ApiAssistAskRequest | ApiAssistAskRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[AskResult, AskAboutReservationErrorBody]:
        """Ask a question about one of the caller's reservations.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/assist/ask"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAssistAskRequest | ApiAssistAskRequestDict](body),
            decoder=async_json_decoder[AskResult],
            error_mapper=ask_about_reservation_error_mapper,
            request_options=request_options,
        )

    async def explain_offer(
        self,
        body: ApiAssistExplainRequest | ApiAssistExplainRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ExplainResult, ExplainOfferErrorBody]:
        """Numbers come from the stored quote; model text is checked against them before it is shown.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/assist/explain"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAssistExplainRequest | ApiAssistExplainRequestDict](body),
            decoder=async_json_decoder[ExplainResult],
            error_mapper=explain_offer_error_mapper,
            request_options=request_options,
        )

    async def parse_charging_request(
        self,
        body: ApiQuotesParseRequest | ApiQuotesParseRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ParseResult, ParseChargingRequestErrorBody]:
        """Fills a form only. It sets no price and approves nothing. Falls back to a labelled deterministic parser when
        no AI provider is available.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/quotes/parse"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiQuotesParseRequest | ApiQuotesParseRequestDict](body),
            decoder=async_json_decoder[ParseResult],
            error_mapper=parse_charging_request_error_mapper,
            request_options=request_options,
        )

    async def recommend_offer(
        self,
        body: ApiAgentDealsRequest | ApiAgentDealsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[DealResult, RecommendOfferErrorBody]:
        """Read-only. It evaluates only offers the backend already priced and never accepts or pays.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/agent/deals"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAgentDealsRequest | ApiAgentDealsRequestDict](body),
            decoder=async_json_decoder[DealResult],
            error_mapper=recommend_offer_error_mapper,
            request_options=request_options,
        )
