from __future__ import annotations

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    async_json_decoder,
    json_decoder,
    param,
    raw_error_response,
    unwrap,
)
from ..errors.get_reservation_error import GetReservationErrorBody, get_reservation_error_mapper
from ..models.api_reservations_response import ApiReservationsResponse
from ..models.api_reservations_response1 import ApiReservationsResponse1
from ..server.server import Server


class Reservations:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = ReservationsWithRawResponse(client, server)

    def get_reservation(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiReservationsResponse1:
        """One reservation with payment state, provider proofs and receipt data.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The reservation

        Raises:
            ApiError: Not found (or not the caller's) ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.get_reservation(id_, request_options=request_options))

    def list_my_reservations(self, *, request_options: RequestOptionsOrDict | None = None) -> ApiReservationsResponse:
        """Reservations made in the caller's driver session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The caller's reservations (empty without a session)

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.list_my_reservations(request_options=request_options))

    @property
    def with_raw_response(self) -> ReservationsWithRawResponse:
        return self._with_raw_response


class AsyncReservations:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncReservationsWithRawResponse(client, server)

    async def get_reservation(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiReservationsResponse1:
        """One reservation with payment state, provider proofs and receipt data.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The reservation

        Raises:
            ApiError: Not found (or not the caller's) ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.get_reservation(id_, request_options=request_options))

    async def list_my_reservations(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiReservationsResponse:
        """Reservations made in the caller's driver session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The caller's reservations (empty without a session)

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.list_my_reservations(request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncReservationsWithRawResponse:
        return self._with_raw_response


class ReservationsWithRawResponse(BaseRawResponse[RawClient, Server]):
    def get_reservation(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiReservationsResponse1, GetReservationErrorBody]:
        """One reservation with payment state, provider proofs and receipt data.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/reservations/{id}"),
            path_params=[param[str]("id", id_)],
            decoder=json_decoder[ApiReservationsResponse1],
            error_mapper=get_reservation_error_mapper,
            request_options=request_options,
        )

    def list_my_reservations(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiReservationsResponse, RawError]:
        """Reservations made in the caller's driver session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/reservations"),
            decoder=json_decoder[ApiReservationsResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )


class AsyncReservationsWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def get_reservation(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiReservationsResponse1, GetReservationErrorBody]:
        """One reservation with payment state, provider proofs and receipt data.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/reservations/{id}"),
            path_params=[param[str]("id", id_)],
            decoder=async_json_decoder[ApiReservationsResponse1],
            error_mapper=get_reservation_error_mapper,
            request_options=request_options,
        )

    async def list_my_reservations(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiReservationsResponse, RawError]:
        """Reservations made in the caller's driver session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/reservations"),
            decoder=async_json_decoder[ApiReservationsResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )
