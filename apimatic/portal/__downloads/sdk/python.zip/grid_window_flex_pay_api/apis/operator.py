from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from ..auth import AsyncAuthSchemes, AuthSchemes
from ..core import (
    ApiResult,
    AsyncRawClient,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    SecuredRawResponse,
    async_json_decoder,
    json_body,
    json_decoder,
    param,
    raw_error_response,
    unwrap,
)
from ..errors.get_operator_dashboard_error import GetOperatorDashboardErrorBody, get_operator_dashboard_error_mapper
from ..errors.operator_sign_in_error import OperatorSignInErrorBody, operator_sign_in_error_mapper
from ..models.api_operator_session_request import ApiOperatorSessionRequest, ApiOperatorSessionRequestDict
from ..models.api_operator_session_response import ApiOperatorSessionResponse
from ..models.operator_session_state import OperatorSessionState
from ..server.server import Server


class Operator:
    def __init__(self, client: RawClient, server: Server, auth: AuthSchemes) -> None:
        self._with_raw_response = OperatorWithRawResponse(client, server, auth)

    def get_operator_dashboard(
        self, *, night: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> Any:
        """Every reservation of a night with load, ports and payment states.

        Args:
            night: Night to show (YYYY-MM-DD, station-local). Defaults to the current charging night.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Dashboard data

        Raises:
            ApiError: Operator session required or passphrase wrong ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.get_operator_dashboard(night=night, request_options=request_options))

    def get_operator_session(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiOperatorSessionResponse:
        """Whether the caller holds an operator session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Session state

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.get_operator_session(request_options=request_options))

    def operator_sign_in(
        self,
        body: ApiOperatorSessionRequest | ApiOperatorSessionRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> OperatorSessionState:
        """Sign in with the operator passphrase.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Signed in; sets the operator cookie

        Raises:
            ApiError: Operator session required or passphrase wrong ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.operator_sign_in(body, request_options=request_options))

    def operator_sign_out(self, *, request_options: RequestOptionsOrDict | None = None) -> OperatorSessionState:
        """Sign out.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Signed out; clears the operator cookie

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.operator_sign_out(request_options=request_options))

    @property
    def with_raw_response(self) -> OperatorWithRawResponse:
        return self._with_raw_response


class AsyncOperator:
    def __init__(self, client: AsyncRawClient, server: Server, auth: AsyncAuthSchemes) -> None:
        self._with_raw_response = AsyncOperatorWithRawResponse(client, server, auth)

    async def get_operator_dashboard(
        self, *, night: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> Any:
        """Every reservation of a night with load, ports and payment states.

        Args:
            night: Night to show (YYYY-MM-DD, station-local). Defaults to the current charging night.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Dashboard data

        Raises:
            ApiError: Operator session required or passphrase wrong ``error`` is ``Error | RawError``."""
        return unwrap(
            await self._with_raw_response.get_operator_dashboard(night=night, request_options=request_options)
        )

    async def get_operator_session(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiOperatorSessionResponse:
        """Whether the caller holds an operator session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Session state

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.get_operator_session(request_options=request_options))

    async def operator_sign_in(
        self,
        body: ApiOperatorSessionRequest | ApiOperatorSessionRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> OperatorSessionState:
        """Sign in with the operator passphrase.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Signed in; sets the operator cookie

        Raises:
            ApiError: Operator session required or passphrase wrong ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.operator_sign_in(body, request_options=request_options))

    async def operator_sign_out(self, *, request_options: RequestOptionsOrDict | None = None) -> OperatorSessionState:
        """Sign out.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Signed out; clears the operator cookie

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.operator_sign_out(request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncOperatorWithRawResponse:
        return self._with_raw_response


class OperatorWithRawResponse(SecuredRawResponse[RawClient, Server, AuthSchemes]):
    def get_operator_dashboard(
        self, *, night: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Any, GetOperatorDashboardErrorBody]:
        """Every reservation of a night with load, ports and payment states.

        Args:
            night: Night to show (YYYY-MM-DD, station-local). Defaults to the current charging night.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/operator/dashboard"),
            query_params=[param[str | None]("night", night)],
            auth_scheme=self._auth.operator_cookie,
            decoder=json_decoder[Any],
            error_mapper=get_operator_dashboard_error_mapper,
            request_options=request_options,
        )

    def get_operator_session(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiOperatorSessionResponse, RawError]:
        """Whether the caller holds an operator session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/operator/session"),
            decoder=json_decoder[ApiOperatorSessionResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def operator_sign_in(
        self,
        body: ApiOperatorSessionRequest | ApiOperatorSessionRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[OperatorSessionState, OperatorSignInErrorBody]:
        """Sign in with the operator passphrase.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/operator/session"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiOperatorSessionRequest | ApiOperatorSessionRequestDict](body),
            decoder=json_decoder[OperatorSessionState],
            error_mapper=operator_sign_in_error_mapper,
            request_options=request_options,
        )

    def operator_sign_out(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[OperatorSessionState, RawError]:
        """Sign out.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="DELETE",
            url_template=self._server.default("/api/operator/session"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            decoder=json_decoder[OperatorSessionState],
            error_mapper=raw_error_response,
            request_options=request_options,
        )


class AsyncOperatorWithRawResponse(SecuredRawResponse[AsyncRawClient, Server, AsyncAuthSchemes]):
    async def get_operator_dashboard(
        self, *, night: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Any, GetOperatorDashboardErrorBody]:
        """Every reservation of a night with load, ports and payment states.

        Args:
            night: Night to show (YYYY-MM-DD, station-local). Defaults to the current charging night.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/operator/dashboard"),
            query_params=[param[str | None]("night", night)],
            auth_scheme=self._auth.operator_cookie,
            decoder=async_json_decoder[Any],
            error_mapper=get_operator_dashboard_error_mapper,
            request_options=request_options,
        )

    async def get_operator_session(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiOperatorSessionResponse, RawError]:
        """Whether the caller holds an operator session.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/operator/session"),
            decoder=async_json_decoder[ApiOperatorSessionResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def operator_sign_in(
        self,
        body: ApiOperatorSessionRequest | ApiOperatorSessionRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[OperatorSessionState, OperatorSignInErrorBody]:
        """Sign in with the operator passphrase.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/operator/session"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiOperatorSessionRequest | ApiOperatorSessionRequestDict](body),
            decoder=async_json_decoder[OperatorSessionState],
            error_mapper=operator_sign_in_error_mapper,
            request_options=request_options,
        )

    async def operator_sign_out(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[OperatorSessionState, RawError]:
        """Sign out.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="DELETE",
            url_template=self._server.default("/api/operator/session"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            decoder=async_json_decoder[OperatorSessionState],
            error_mapper=raw_error_response,
            request_options=request_options,
        )
