from __future__ import annotations

from uuid import UUID, uuid4

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    async_empty_response,
    async_json_decoder,
    empty_response,
    json_body,
    json_decoder,
    param,
    raw_error_response,
    unwrap,
)
from ..errors.accept_offer_error import AcceptOfferErrorBody, accept_offer_error_mapper
from ..models.api_offers_accept_request import ApiOffersAcceptRequest, ApiOffersAcceptRequestDict
from ..models.api_offers_accept_response import ApiOffersAcceptResponse
from ..server.server import Server


class Checkout:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = CheckoutWithRawResponse(client, server)

    def accept_offer(
        self,
        body: ApiOffersAcceptRequest | ApiOffersAcceptRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiOffersAcceptResponse:
        """Requires the driver's explicit consent (``consent: true``) and the ``termsHash`` the driver saw; tampered or
        expired terms are refused. Returns the PayPal approval link. Nothing is authorized or charged until the buyer
        approves in PayPal.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Reservation created, waiting for buyer approval

        Raises:
            ApiError: Not found (or not the caller's) The request conflicts with current state (expired offer, terms
                mismatch, already accepted, ...) ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.accept_offer(body, request_options=request_options))

    def checkout_cancel(self, rid: str, state: str, *, request_options: RequestOptionsOrDict | None = None) -> None:
        """PayPal cancel URL. Cancels the pending order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.checkout_cancel(rid, state, request_options=request_options))

    def checkout_return(
        self, rid: str, state: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """PayPal return URL. Authorizes the approved order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Signed anti-forgery state
            token: PayPal order id
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.checkout_return(rid, state, token, request_options=request_options))

    @property
    def with_raw_response(self) -> CheckoutWithRawResponse:
        return self._with_raw_response


class AsyncCheckout:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncCheckoutWithRawResponse(client, server)

    async def accept_offer(
        self,
        body: ApiOffersAcceptRequest | ApiOffersAcceptRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiOffersAcceptResponse:
        """Requires the driver's explicit consent (``consent: true``) and the ``termsHash`` the driver saw; tampered or
        expired terms are refused. Returns the PayPal approval link. Nothing is authorized or charged until the buyer
        approves in PayPal.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Reservation created, waiting for buyer approval

        Raises:
            ApiError: Not found (or not the caller's) The request conflicts with current state (expired offer, terms
                mismatch, already accepted, ...) ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.accept_offer(body, request_options=request_options))

    async def checkout_cancel(
        self, rid: str, state: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """PayPal cancel URL. Cancels the pending order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.checkout_cancel(rid, state, request_options=request_options))

    async def checkout_return(
        self, rid: str, state: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """PayPal return URL. Authorizes the approved order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Signed anti-forgery state
            token: PayPal order id
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.checkout_return(rid, state, token, request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncCheckoutWithRawResponse:
        return self._with_raw_response


class CheckoutWithRawResponse(BaseRawResponse[RawClient, Server]):
    def accept_offer(
        self,
        body: ApiOffersAcceptRequest | ApiOffersAcceptRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiOffersAcceptResponse, AcceptOfferErrorBody]:
        """Requires the driver's explicit consent (``consent: true``) and the ``termsHash`` the driver saw; tampered or
        expired terms are refused. Returns the PayPal approval link. Nothing is authorized or charged until the buyer
        approves in PayPal.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/offers/accept"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiOffersAcceptRequest | ApiOffersAcceptRequestDict](body),
            decoder=json_decoder[ApiOffersAcceptResponse],
            error_mapper=accept_offer_error_mapper,
            request_options=request_options,
        )

    def checkout_cancel(
        self, rid: str, state: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """PayPal cancel URL. Cancels the pending order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/checkout/cancel"),
            query_params=[param[str]("rid", rid), param[str]("state", state)],
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def checkout_return(
        self, rid: str, state: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """PayPal return URL. Authorizes the approved order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Signed anti-forgery state
            token: PayPal order id
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/checkout/return"),
            query_params=[param[str]("rid", rid), param[str]("state", state), param[str]("token", token)],
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )


class AsyncCheckoutWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def accept_offer(
        self,
        body: ApiOffersAcceptRequest | ApiOffersAcceptRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiOffersAcceptResponse, AcceptOfferErrorBody]:
        """Requires the driver's explicit consent (``consent: true``) and the ``termsHash`` the driver saw; tampered or
        expired terms are refused. Returns the PayPal approval link. Nothing is authorized or charged until the buyer
        approves in PayPal.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/offers/accept"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiOffersAcceptRequest | ApiOffersAcceptRequestDict](body),
            decoder=async_json_decoder[ApiOffersAcceptResponse],
            error_mapper=accept_offer_error_mapper,
            request_options=request_options,
        )

    async def checkout_cancel(
        self, rid: str, state: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """PayPal cancel URL. Cancels the pending order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/checkout/cancel"),
            query_params=[param[str]("rid", rid), param[str]("state", state)],
            decoder=async_empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def checkout_return(
        self, rid: str, state: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """PayPal return URL. Authorizes the approved order, then redirects to the reservation.

        Args:
            rid: Value sent with the request.
            state: Signed anti-forgery state
            token: PayPal order id
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/checkout/return"),
            query_params=[param[str]("rid", rid), param[str]("state", state), param[str]("token", token)],
            decoder=async_empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )
