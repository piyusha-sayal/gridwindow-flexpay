from __future__ import annotations

from functools import cached_property
from types import TracebackType

from typing_extensions import Self

from .apis.ai_api import AiApi
from .apis.checkout import Checkout
from .apis.offers import Offers
from .apis.operator import Operator
from .apis.reservations import Reservations
from .apis.site import Site
from .apis.webhooks import Webhooks
from .auth import AuthSchemes
from .base_client import DEFAULT_TIMEOUT, BaseGridWindowFlexPayApiClient
from .core import (
    OPERATING_SYSTEM,
    PYTHON_RUNTIME,
    ApiKeyCookieScheme,
    HttpClient,
    Httpx2Client,
    LoggingOptionsOrDict,
    RawClient,
    RetryOptionsOrDict,
    no_auth,
    param,
)
from .server.environment import Environment


class GridWindowFlexPayApiClient(BaseGridWindowFlexPayApiClient[RawClient]):
    def __init__(
        self,
        *,
        environment: Environment = "production",
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_options: int | RetryOptionsOrDict | None = None,
        logging_options: LoggingOptionsOrDict | None = None,
        custom_http_client: HttpClient | None = None,
        operator_cookie: str | None = None,
    ) -> None:
        super().__init__(
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            retry_options=retry_options,
            logging_options=logging_options,
        )
        self._raw_client = RawClient(
            http_client=custom_http_client if custom_http_client is not None else Httpx2Client(timeout=timeout),
            retry_options=self._retry_options,
            logging_options=self._logging_options,
            global_headers=[
                param[str]("User-Agent", "GridWindowFlexPayApiClient/1.0.0 Python"),
                param[str]("X-APIMatic-Lang", "Python"),
                param[str]("X-APIMatic-Package-Version", "1.0.0"),
                param[str]("X-APIMatic-Gen-Version", "4.0.0"),
                param[str]("X-APIMatic-OS", OPERATING_SYSTEM),
                param[str]("X-APIMatic-Runtime", PYTHON_RUNTIME),
            ],
        )
        self._auth = AuthSchemes(
            operator_cookie=ApiKeyCookieScheme("gw_op", operator_cookie) if operator_cookie is not None else no_auth
        )

    @cached_property
    def ai_api(self) -> AiApi:
        return AiApi(self._raw_client, self._server)

    @cached_property
    def checkout(self) -> Checkout:
        return Checkout(self._raw_client, self._server)

    @cached_property
    def offers(self) -> Offers:
        return Offers(self._raw_client, self._server)

    @cached_property
    def operator(self) -> Operator:
        return Operator(self._raw_client, self._server, self._auth)

    @cached_property
    def reservations(self) -> Reservations:
        return Reservations(self._raw_client, self._server)

    @cached_property
    def site(self) -> Site:
        return Site(self._raw_client, self._server)

    @cached_property
    def webhooks(self) -> Webhooks:
        return Webhooks(self._raw_client, self._server)

    def close(self) -> None:
        self._raw_client.http_client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None
    ) -> None:
        self.close()


Client = GridWindowFlexPayApiClient
