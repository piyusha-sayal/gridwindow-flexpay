from __future__ import annotations

from functools import cached_property
from types import TracebackType

from typing_extensions import Self

from .apis.ai_api import AsyncAiApi
from .apis.checkout import AsyncCheckout
from .apis.offers import AsyncOffers
from .apis.operator import AsyncOperator
from .apis.reservations import AsyncReservations
from .apis.site import AsyncSite
from .apis.webhooks import AsyncWebhooks
from .auth import AsyncAuthSchemes
from .base_client import DEFAULT_TIMEOUT, BaseGridWindowFlexPayApiClient
from .core import (
    OPERATING_SYSTEM,
    PYTHON_RUNTIME,
    ApiKeyCookieScheme,
    AsyncHttpClient,
    AsyncHttpx2Client,
    AsyncRawClient,
    LoggingOptionsOrDict,
    RetryOptionsOrDict,
    no_auth,
    param,
)
from .server.environment import Environment


class AsyncGridWindowFlexPayApiClient(BaseGridWindowFlexPayApiClient[AsyncRawClient]):
    def __init__(
        self,
        *,
        environment: Environment = "production",
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_options: int | RetryOptionsOrDict | None = None,
        logging_options: LoggingOptionsOrDict | None = None,
        custom_async_http_client: AsyncHttpClient | None = None,
        operator_cookie: str | None = None,
    ) -> None:
        super().__init__(
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            retry_options=retry_options,
            logging_options=logging_options,
        )
        self._raw_client = AsyncRawClient(
            http_client=(
                custom_async_http_client if custom_async_http_client is not None else AsyncHttpx2Client(timeout=timeout)
            ),
            retry_options=self._retry_options,
            logging_options=self._logging_options,
            global_headers=[
                param[str]("User-Agent", "GridWindowFlexPayApiClient/1.0.0 Python"),
                param[str]("X-APIMatic-Lang", "Python"),
                param[str]("X-APIMatic-Package-Version", "1.0.0"),
                param[str]("X-APIMatic-Gen-Version", "4.0.0"),
                param[str]("X-APIMatic-OS", OPERATING_SYSTEM),
                param[str]("X-APIMatic-Runtime", PYTHON_RUNTIME),
            ],
        )
        self._auth = AsyncAuthSchemes(
            operator_cookie=ApiKeyCookieScheme("gw_op", operator_cookie) if operator_cookie is not None else no_auth
        )

    @cached_property
    def ai_api(self) -> AsyncAiApi:
        return AsyncAiApi(self._raw_client, self._server)

    @cached_property
    def checkout(self) -> AsyncCheckout:
        return AsyncCheckout(self._raw_client, self._server)

    @cached_property
    def offers(self) -> AsyncOffers:
        return AsyncOffers(self._raw_client, self._server)

    @cached_property
    def operator(self) -> AsyncOperator:
        return AsyncOperator(self._raw_client, self._server, self._auth)

    @cached_property
    def reservations(self) -> AsyncReservations:
        return AsyncReservations(self._raw_client, self._server)

    @cached_property
    def site(self) -> AsyncSite:
        return AsyncSite(self._raw_client, self._server)

    @cached_property
    def webhooks(self) -> AsyncWebhooks:
        return AsyncWebhooks(self._raw_client, self._server)

    async def aclose(self) -> None:
        await self._raw_client.http_client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None
    ) -> None:
        await self.aclose()


AsyncClient = AsyncGridWindowFlexPayApiClient
