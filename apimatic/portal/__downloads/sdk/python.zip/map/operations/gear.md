<!-- Generated file — do not edit; regenerated with the SDK. -->

# Gear — operations

Accessor: `client.gear` · Source: `grid_window_flex_pay_api/apis/gear.py` · 1 operation

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.gear.find_ev_gear

- **Route**: `GET /api/gear`
- **Signature**: `def find_ev_gear(*, q: str | None = None, max_price_cents: int | None = None, limit: int | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `q` — query · `max_price_cents` — query `maxPriceCents` · `limit` — query
- **Returns (parsed)**: `ApiGearResponse`
- **Returns (raw)**: `ApiResult[ApiGearResponse, FindEvGearErrorBody]`
- **Error**: `FindEvGearErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [429] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiGearResponse` | `grid_window_flex_pay_api/models/api_gear_response.py` |
| `FindEvGearErrorBody` | `grid_window_flex_pay_api/errors/find_ev_gear_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

