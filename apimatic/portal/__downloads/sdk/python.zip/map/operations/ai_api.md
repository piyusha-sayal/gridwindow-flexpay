<!-- Generated file — do not edit; regenerated with the SDK. -->

# AiApi — operations

Accessor: `client.ai_api` · Source: `grid_window_flex_pay_api/apis/ai_api.py` · 4 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.ai_api.ask_about_reservation

- **Route**: `POST /api/assist/ask`
- **Signature**: `def ask_about_reservation(body: ApiAssistAskRequest | ApiAssistAskRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, AskAboutReservationErrorBody]`
- **Error**: `AskAboutReservationErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [404] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiAssistAskRequest` | `grid_window_flex_pay_api/models/api_assist_ask_request.py` |
| `ApiAssistAskRequestDict` | `grid_window_flex_pay_api/models/api_assist_ask_request.py` |
| `AskAboutReservationErrorBody` | `grid_window_flex_pay_api/errors/ask_about_reservation_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

### client.ai_api.explain_offer

- **Route**: `POST /api/assist/explain`
- **Signature**: `def explain_offer(body: ApiAssistExplainRequest | ApiAssistExplainRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, ExplainOfferErrorBody]`
- **Error**: `ExplainOfferErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [404] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiAssistExplainRequest` | `grid_window_flex_pay_api/models/api_assist_explain_request.py` |
| `ApiAssistExplainRequestDict` | `grid_window_flex_pay_api/models/api_assist_explain_request.py` |
| `ExplainOfferErrorBody` | `grid_window_flex_pay_api/errors/explain_offer_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

### client.ai_api.parse_charging_request

- **Route**: `POST /api/quotes/parse`
- **Signature**: `def parse_charging_request(body: ApiQuotesParseRequest | ApiQuotesParseRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `ParseResult`
- **Returns (raw)**: `ApiResult[ParseResult, ParseChargingRequestErrorBody]`
- **Error**: `ParseChargingRequestErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [400, 429] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiQuotesParseRequest` | `grid_window_flex_pay_api/models/api_quotes_parse_request.py` |
| `ApiQuotesParseRequestDict` | `grid_window_flex_pay_api/models/api_quotes_parse_request.py` |
| `ParseResult` | `grid_window_flex_pay_api/models/parse_result.py` |
| `ParseChargingRequestErrorBody` | `grid_window_flex_pay_api/errors/parse_charging_request_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

### client.ai_api.recommend_offer

- **Route**: `POST /api/agent/deals`
- **Signature**: `def recommend_offer(body: ApiAgentDealsRequest | ApiAgentDealsRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `DealResult`
- **Returns (raw)**: `ApiResult[DealResult, RecommendOfferErrorBody]`
- **Error**: `RecommendOfferErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [404, 409] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiAgentDealsRequest` | `grid_window_flex_pay_api/models/api_agent_deals_request.py` |
| `ApiAgentDealsRequestDict` | `grid_window_flex_pay_api/models/api_agent_deals_request.py` |
| `DealResult` | `grid_window_flex_pay_api/models/deal_result.py` |
| `RecommendOfferErrorBody` | `grid_window_flex_pay_api/errors/recommend_offer_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

