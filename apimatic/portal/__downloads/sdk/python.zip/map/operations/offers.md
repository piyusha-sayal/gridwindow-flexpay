<!-- Generated file — do not edit; regenerated with the SDK. -->

# Offers — operations

Accessor: `client.offers` · Source: `grid_window_flex_pay_api/apis/offers.py` · 1 operation

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.offers.request_offers

- **Route**: `POST /api/quotes`
- **Signature**: `def request_offers(body: QuoteRequest | QuoteRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `ApiQuotesResponse`
- **Returns (raw)**: `ApiResult[ApiQuotesResponse, RequestOffersErrorBody]`
- **Error**: `RequestOffersErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [400, 403, 409, 429] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `QuoteRequest` | `grid_window_flex_pay_api/models/quote_request.py` |
| `QuoteRequestDict` | `grid_window_flex_pay_api/models/quote_request.py` |
| `ApiQuotesResponse` | `grid_window_flex_pay_api/models/api_quotes_response.py` |
| `RequestOffersErrorBody` | `grid_window_flex_pay_api/errors/request_offers_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

