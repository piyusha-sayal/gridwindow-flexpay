<!-- Generated file — do not edit; regenerated with the SDK. -->

# Reservations — operations

Accessor: `client.reservations` · Source: `grid_window_flex_pay_api/apis/reservations.py` · 2 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.reservations.get_reservation

- **Route**: `GET /api/reservations/{id}`
- **Signature**: `def get_reservation(id_: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`
- **Params**: `id_` — path `id`
- **Returns (parsed)**: `ApiReservationsResponse1`
- **Returns (raw)**: `ApiResult[ApiReservationsResponse1, GetReservationErrorBody]`
- **Error**: `GetReservationErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [404] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiReservationsResponse1` | `grid_window_flex_pay_api/models/api_reservations_response1.py` |
| `GetReservationErrorBody` | `grid_window_flex_pay_api/errors/get_reservation_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

### client.reservations.list_my_reservations

- **Route**: `GET /api/reservations`
- **Signature**: `def list_my_reservations(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `ApiReservationsResponse`
- **Returns (raw)**: `ApiResult[ApiReservationsResponse, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiReservationsResponse` | `grid_window_flex_pay_api/models/api_reservations_response.py` |

