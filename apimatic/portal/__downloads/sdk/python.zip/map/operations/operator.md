<!-- Generated file — do not edit; regenerated with the SDK. -->

# Operator — operations

Accessor: `client.operator` · Source: `grid_window_flex_pay_api/apis/operator.py` · 4 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded, and an operation with no table mentions nothing but builtins and those.

### client.operator.get_operator_dashboard

- **Route**: `GET /api/operator/dashboard`
- **Auth**: `operator_cookie`
- **Signature**: `def get_operator_dashboard(*, night_of: str | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `night_of` — query `nightOf`
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, GetOperatorDashboardErrorBody]`
- **Error**: `GetOperatorDashboardErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [401] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `GetOperatorDashboardErrorBody` | `grid_window_flex_pay_api/errors/get_operator_dashboard_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

### client.operator.get_operator_session

- **Route**: `GET /api/operator/session`
- **Signature**: `def get_operator_session(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `ApiOperatorSessionResponse`
- **Returns (raw)**: `ApiResult[ApiOperatorSessionResponse, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiOperatorSessionResponse` | `grid_window_flex_pay_api/models/api_operator_session_response.py` |

### client.operator.operator_sign_in

- **Route**: `POST /api/operator/session`
- **Signature**: `def operator_sign_in(body: ApiOperatorSessionRequest | ApiOperatorSessionRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, OperatorSignInErrorBody]`
- **Error**: `OperatorSignInErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [401] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiOperatorSessionRequest` | `grid_window_flex_pay_api/models/api_operator_session_request.py` |
| `ApiOperatorSessionRequestDict` | `grid_window_flex_pay_api/models/api_operator_session_request.py` |
| `OperatorSignInErrorBody` | `grid_window_flex_pay_api/errors/operator_sign_in_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

### client.operator.operator_sign_out

- **Route**: `DELETE /api/operator/session`
- **Signature**: `def operator_sign_out(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

