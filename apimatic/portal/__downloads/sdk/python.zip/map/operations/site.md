<!-- Generated file — do not edit; regenerated with the SDK. -->

# Site — operations

Accessor: `client.site` · Source: `grid_window_flex_pay_api/apis/site.py` · 1 operation

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.site.get_site_config

- **Route**: `GET /api/config`
- **Signature**: `def get_site_config(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `SiteConfig`
- **Returns (raw)**: `ApiResult[SiteConfig, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `SiteConfig` | `grid_window_flex_pay_api/models/site_config.py` |

