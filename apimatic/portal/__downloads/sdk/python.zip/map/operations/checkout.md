<!-- Generated file — do not edit; regenerated with the SDK. -->

# Checkout — operations

Accessor: `client.checkout` · Source: `grid_window_flex_pay_api/apis/checkout.py` · 3 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded, and an operation with no table mentions nothing but builtins and those.

### client.checkout.accept_offer

- **Route**: `POST /api/offers/accept`
- **Signature**: `def accept_offer(body: ApiOffersAcceptRequest | ApiOffersAcceptRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `ApiOffersAcceptResponse`
- **Returns (raw)**: `ApiResult[ApiOffersAcceptResponse, AcceptOfferErrorBody]`
- **Error**: `AcceptOfferErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [404, 409] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiOffersAcceptRequest` | `grid_window_flex_pay_api/models/api_offers_accept_request.py` |
| `ApiOffersAcceptRequestDict` | `grid_window_flex_pay_api/models/api_offers_accept_request.py` |
| `ApiOffersAcceptResponse` | `grid_window_flex_pay_api/models/api_offers_accept_response.py` |
| `AcceptOfferErrorBody` | `grid_window_flex_pay_api/errors/accept_offer_error.py` |
| `Error` | `grid_window_flex_pay_api/models/error.py` |

### client.checkout.checkout_cancel

- **Route**: `GET /api/checkout/cancel`
- **Signature**: `def checkout_cancel(rid: str, state: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `rid`, `state`
- **Params**: `rid` — query · `state` — query
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.checkout.checkout_return

- **Route**: `GET /api/checkout/return`
- **Signature**: `def checkout_return(rid: str, state: str, token: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `rid`, `state`, `token`
- **Params**: `rid` — query · `state` — query · `token` — query
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

