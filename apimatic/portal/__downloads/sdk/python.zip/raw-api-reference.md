# Raw Reference

**Raw** endpoints, reached through `with_raw_response`, return `ApiResult[T, E]` and never raise for an API error. For the parsed endpoints, see [API Reference](api-reference.md).

> Source: [GridWindowFlexPayApiClient](grid_window_flex_pay_api/client.py)

## AiApi

> Source: [AiApi](grid_window_flex_pay_api/apis/ai_api.py)

<details>
<summary><code>def ask_about_reservation(body: ApiAssistAskRequest | ApiAssistAskRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[AskResult, AskAboutReservationErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Ask a question about one of the caller's reservations.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.ai_api.with_raw_response.ask_about_reservation(
    ApiAssistAskRequest(reservation_id="some example string", question="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type AskResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type AskAboutReservationErrorBody
```

**Async**

```python
result = await async_client.ai_api.with_raw_response.ask_about_reservation(
    ApiAssistAskRequest(reservation_id="some example string", question="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type AskResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type AskAboutReservationErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAssistAskRequest](grid_window_flex_pay_api/models/api_assist_ask_request.py) \| [ApiAssistAskRequestDict](grid_window_flex_pay_api/models/api_assist_ask_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[AskResult](grid_window_flex_pay_api/models/ask_result.py), [AskAboutReservationErrorBody](grid_window_flex_pay_api/errors/ask_about_reservation_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[AskResult](grid_window_flex_pay_api/models/ask_result.py)</code> -- Grounded answer and its source

**On `Failure`**: `error` is <code>[AskAboutReservationErrorBody](grid_window_flex_pay_api/errors/ask_about_reservation_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def explain_offer(body: ApiAssistExplainRequest | ApiAssistExplainRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ExplainResult, ExplainOfferErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Numbers come from the stored quote; model text is checked against them before it is shown.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.ai_api.with_raw_response.explain_offer(
    ApiAssistExplainRequest(quote_set_id="some example string", offer_id="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ExplainResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type ExplainOfferErrorBody
```

**Async**

```python
result = await async_client.ai_api.with_raw_response.explain_offer(
    ApiAssistExplainRequest(quote_set_id="some example string", offer_id="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ExplainResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type ExplainOfferErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAssistExplainRequest](grid_window_flex_pay_api/models/api_assist_explain_request.py) \| [ApiAssistExplainRequestDict](grid_window_flex_pay_api/models/api_assist_explain_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ExplainResult](grid_window_flex_pay_api/models/explain_result.py), [ExplainOfferErrorBody](grid_window_flex_pay_api/errors/explain_offer_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[ExplainResult](grid_window_flex_pay_api/models/explain_result.py)</code> -- Explanation and its source

**On `Failure`**: `error` is <code>[ExplainOfferErrorBody](grid_window_flex_pay_api/errors/explain_offer_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def parse_charging_request(body: ApiQuotesParseRequest | ApiQuotesParseRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ParseResult, ParseChargingRequestErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Fills a form only. It sets no price and approves nothing. Falls back to a labelled deterministic parser when no AI provider is available.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.ai_api.with_raw_response.parse_charging_request(ApiQuotesParseRequest(text="some example string"))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ParseResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type ParseChargingRequestErrorBody
```

**Async**

```python
result = await async_client.ai_api.with_raw_response.parse_charging_request(
    ApiQuotesParseRequest(text="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ParseResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type ParseChargingRequestErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiQuotesParseRequest](grid_window_flex_pay_api/models/api_quotes_parse_request.py) \| [ApiQuotesParseRequestDict](grid_window_flex_pay_api/models/api_quotes_parse_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ParseResult](grid_window_flex_pay_api/models/parse_result.py), [ParseChargingRequestErrorBody](grid_window_flex_pay_api/errors/parse_charging_request_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[ParseResult](grid_window_flex_pay_api/models/parse_result.py)</code> -- Parsed fields and their source

**On `Failure`**: `error` is <code>[ParseChargingRequestErrorBody](grid_window_flex_pay_api/errors/parse_charging_request_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 429 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def recommend_offer(body: ApiAgentDealsRequest | ApiAgentDealsRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[DealResult, RecommendOfferErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Read-only. It evaluates only offers the backend already priced and never accepts or pays.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.ai_api.with_raw_response.recommend_offer(
    ApiAgentDealsRequest(quote_set_id="some example string", min_savings_cents=1, preference=Preference.LOWEST_COST)
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type DealResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RecommendOfferErrorBody
```

**Async**

```python
result = await async_client.ai_api.with_raw_response.recommend_offer(
    ApiAgentDealsRequest(quote_set_id="some example string", min_savings_cents=1, preference=Preference.LOWEST_COST)
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type DealResult
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RecommendOfferErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAgentDealsRequest](grid_window_flex_pay_api/models/api_agent_deals_request.py) \| [ApiAgentDealsRequestDict](grid_window_flex_pay_api/models/api_agent_deals_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[DealResult](grid_window_flex_pay_api/models/deal_result.py), [RecommendOfferErrorBody](grid_window_flex_pay_api/errors/recommend_offer_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[DealResult](grid_window_flex_pay_api/models/deal_result.py)</code> -- The recommendation and the evaluation behind it

**On `Failure`**: `error` is <code>[RecommendOfferErrorBody](grid_window_flex_pay_api/errors/recommend_offer_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404, 409 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

## Checkout

> Source: [Checkout](grid_window_flex_pay_api/apis/checkout.py)

<details>
<summary><code>def accept_offer(body: ApiOffersAcceptRequest | ApiOffersAcceptRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ApiOffersAcceptResponse, AcceptOfferErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires the driver's explicit consent (`consent: true`) and the `termsHash` the driver saw; tampered or expired
terms are refused. Returns the PayPal approval link. Nothing is authorized or charged until the buyer approves in PayPal.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.checkout.with_raw_response.accept_offer(
    ApiOffersAcceptRequest(
        quote_set_id="some example string",
        offer_id="some example string",
        terms_hash="some example string",
        consent=True,
    ),
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiOffersAcceptResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type AcceptOfferErrorBody
```

**Async**

```python
result = await async_client.checkout.with_raw_response.accept_offer(
    ApiOffersAcceptRequest(
        quote_set_id="some example string",
        offer_id="some example string",
        terms_hash="some example string",
        consent=True,
    ),
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiOffersAcceptResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type AcceptOfferErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiOffersAcceptRequest](grid_window_flex_pay_api/models/api_offers_accept_request.py) \| [ApiOffersAcceptRequestDict](grid_window_flex_pay_api/models/api_offers_accept_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ApiOffersAcceptResponse](grid_window_flex_pay_api/models/api_offers_accept_response.py), [AcceptOfferErrorBody](grid_window_flex_pay_api/errors/accept_offer_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[ApiOffersAcceptResponse](grid_window_flex_pay_api/models/api_offers_accept_response.py)</code> -- Reservation created, waiting for buyer approval

**On `Failure`**: `error` is <code>[AcceptOfferErrorBody](grid_window_flex_pay_api/errors/accept_offer_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404, 409 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def checkout_cancel(rid: str, state: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

PayPal cancel URL. Cancels the pending order, then redirects to the reservation.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.checkout.with_raw_response.checkout_cancel("some example string", "some example string")
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.checkout.with_raw_response.checkout_cancel("some example string", "some example string")
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>rid</code> | <code>str</code> | Value sent with the request. |
| <code>state</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;None, [RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](grid_window_flex_pay_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def checkout_return(rid: str, state: str, token: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

PayPal return URL. Authorizes the approved order, then redirects to the reservation.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.checkout.with_raw_response.checkout_return(
    "some example string", "some example string", "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.checkout.with_raw_response.checkout_return(
    "some example string", "some example string", "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>rid</code> | <code>str</code> | Value sent with the request. |
| <code>state</code> | <code>str</code> | Signed anti-forgery state |
| <code>token</code> | <code>str</code> | PayPal order id |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;None, [RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](grid_window_flex_pay_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Gear

> Source: [Gear](grid_window_flex_pay_api/apis/gear.py)

<details>
<summary><code>def find_ev_gear(*, q: str | None = None, max_price_cents: int | None = None, limit: int | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ApiGearResponse, FindEvGearErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Read-only product search through Channel3. Returns merchant links; nothing is bought. `enabled` is false when no Channel3 key is configured on the server.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.gear.with_raw_response.find_ev_gear(q="J1772 to Tesla adapter", max_price_cents=6000, limit=6)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiGearResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type FindEvGearErrorBody
```

**Async**

```python
result = await async_client.gear.with_raw_response.find_ev_gear(
    q="J1772 to Tesla adapter", max_price_cents=6000, limit=6
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiGearResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type FindEvGearErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>q</code> | <code>str \| None</code> | Search text; defaults to common EV charging accessories.<br>**Default**: <code>None</code> |
| <code>max_price_cents</code> | <code>int \| None</code> | Price cap in US cents.<br>**Default**: <code>None</code> |
| <code>limit</code> | <code>int \| None</code> | Number of results (1-12).<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ApiGearResponse](grid_window_flex_pay_api/models/api_gear_response.py), [FindEvGearErrorBody](grid_window_flex_pay_api/errors/find_ev_gear_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[ApiGearResponse](grid_window_flex_pay_api/models/api_gear_response.py)</code> -- Search result

**On `Failure`**: `error` is <code>[FindEvGearErrorBody](grid_window_flex_pay_api/errors/find_ev_gear_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 429 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

## Offers

> Source: [Offers](grid_window_flex_pay_api/apis/offers.py)

<details>
<summary><code>def request_offers(body: QuoteRequest | QuoteRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ApiQuotesResponse, RequestOffersErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Creates the driver session cookie if absent. Each offer carries exact terms and their SHA-256 `termsHash`, which accept must echo.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.offers.with_raw_response.request_offers(
    QuoteRequest(
        port_id="some example string",
        night_of="some example string",
        plug_in_local="some example string",
        depart_local="some example string",
        target_battery_k_wh=1.5,
        spend_cap_cents=1,
    ),
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiQuotesResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RequestOffersErrorBody
```

**Async**

```python
result = await async_client.offers.with_raw_response.request_offers(
    QuoteRequest(
        port_id="some example string",
        night_of="some example string",
        plug_in_local="some example string",
        depart_local="some example string",
        target_battery_k_wh=1.5,
        spend_cap_cents=1,
    ),
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiQuotesResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RequestOffersErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[QuoteRequest](grid_window_flex_pay_api/models/quote_request.py) \| [QuoteRequestDict](grid_window_flex_pay_api/models/quote_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ApiQuotesResponse](grid_window_flex_pay_api/models/api_quotes_response.py), [RequestOffersErrorBody](grid_window_flex_pay_api/errors/request_offers_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[ApiQuotesResponse](grid_window_flex_pay_api/models/api_quotes_response.py)</code> -- The quote set

**On `Failure`**: `error` is <code>[RequestOffersErrorBody](grid_window_flex_pay_api/errors/request_offers_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 403, 409, 429 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

## Operator

> Source: [Operator](grid_window_flex_pay_api/apis/operator.py)

<details>
<summary><code>def get_operator_dashboard(*, night: str | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Any, GetOperatorDashboardErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Every reservation of a night with load, ports and payment states.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.operator.with_raw_response.get_operator_dashboard(night="2026-11-12")
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type GetOperatorDashboardErrorBody
```

**Async**

```python
result = await async_client.operator.with_raw_response.get_operator_dashboard(night="2026-11-12")
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type GetOperatorDashboardErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>night</code> | <code>str \| None</code> | Night to show (YYYY-MM-DD, station-local). Defaults to the current charging night.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;Any, [GetOperatorDashboardErrorBody](grid_window_flex_pay_api/errors/get_operator_dashboard_error.py)&#93;</code>

**On `Success`**: `payload` is <code>Any</code> -- Dashboard data

**On `Failure`**: `error` is <code>[GetOperatorDashboardErrorBody](grid_window_flex_pay_api/errors/get_operator_dashboard_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 401 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_operator_session(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ApiOperatorSessionResponse, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Whether the caller holds an operator session.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.operator.with_raw_response.get_operator_session()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiOperatorSessionResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.operator.with_raw_response.get_operator_session()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiOperatorSessionResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ApiOperatorSessionResponse](grid_window_flex_pay_api/models/api_operator_session_response.py), [RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[ApiOperatorSessionResponse](grid_window_flex_pay_api/models/api_operator_session_response.py)</code> -- Session state

**On `Failure`**: `error` is <code>[RawError](grid_window_flex_pay_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def operator_sign_in(body: ApiOperatorSessionRequest | ApiOperatorSessionRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[OperatorSessionState, OperatorSignInErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Sign in with the operator passphrase.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.operator.with_raw_response.operator_sign_in(ApiOperatorSessionRequest(passphrase="some example string"))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type OperatorSessionState
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type OperatorSignInErrorBody
```

**Async**

```python
result = await async_client.operator.with_raw_response.operator_sign_in(
    ApiOperatorSessionRequest(passphrase="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type OperatorSessionState
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type OperatorSignInErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiOperatorSessionRequest](grid_window_flex_pay_api/models/api_operator_session_request.py) \| [ApiOperatorSessionRequestDict](grid_window_flex_pay_api/models/api_operator_session_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[OperatorSessionState](grid_window_flex_pay_api/models/operator_session_state.py), [OperatorSignInErrorBody](grid_window_flex_pay_api/errors/operator_sign_in_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[OperatorSessionState](grid_window_flex_pay_api/models/operator_session_state.py)</code> -- Signed in; sets the operator cookie

**On `Failure`**: `error` is <code>[OperatorSignInErrorBody](grid_window_flex_pay_api/errors/operator_sign_in_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 401 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def operator_sign_out(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[OperatorSessionState, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Sign out.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.operator.with_raw_response.operator_sign_out()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type OperatorSessionState
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.operator.with_raw_response.operator_sign_out()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type OperatorSessionState
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[OperatorSessionState](grid_window_flex_pay_api/models/operator_session_state.py), [RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[OperatorSessionState](grid_window_flex_pay_api/models/operator_session_state.py)</code> -- Signed out; clears the operator cookie

**On `Failure`**: `error` is <code>[RawError](grid_window_flex_pay_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Reservations

> Source: [Reservations](grid_window_flex_pay_api/apis/reservations.py)

<details>
<summary><code>def get_reservation(id_: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ApiReservationsResponse1, GetReservationErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

One reservation with payment state, provider proofs and receipt data.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.reservations.with_raw_response.get_reservation("some example string")
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiReservationsResponse1
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type GetReservationErrorBody
```

**Async**

```python
result = await async_client.reservations.with_raw_response.get_reservation("some example string")
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiReservationsResponse1
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type GetReservationErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ApiReservationsResponse1](grid_window_flex_pay_api/models/api_reservations_response1.py), [GetReservationErrorBody](grid_window_flex_pay_api/errors/get_reservation_error.py)&#93;</code>

**On `Success`**: `payload` is <code>[ApiReservationsResponse1](grid_window_flex_pay_api/models/api_reservations_response1.py)</code> -- The reservation

**On `Failure`**: `error` is <code>[GetReservationErrorBody](grid_window_flex_pay_api/errors/get_reservation_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](grid_window_flex_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def list_my_reservations(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[ApiReservationsResponse, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Reservations made in the caller's driver session.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.reservations.with_raw_response.list_my_reservations()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiReservationsResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.reservations.with_raw_response.list_my_reservations()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type ApiReservationsResponse
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[ApiReservationsResponse](grid_window_flex_pay_api/models/api_reservations_response.py), [RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[ApiReservationsResponse](grid_window_flex_pay_api/models/api_reservations_response.py)</code> -- The caller's reservations (empty without a session)

**On `Failure`**: `error` is <code>[RawError](grid_window_flex_pay_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Site

> Source: [Site](grid_window_flex_pay_api/apis/site.py)

<details>
<summary><code>def get_site_config(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[SiteConfig, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Station, ports, payment mode, AI status and the default charging window.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.site.with_raw_response.get_site_config()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type SiteConfig
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.site.with_raw_response.get_site_config()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type SiteConfig
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;[SiteConfig](grid_window_flex_pay_api/models/site_config.py), [RawError](grid_window_flex_pay_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[SiteConfig](grid_window_flex_pay_api/models/site_config.py)</code> -- Site configuration

**On `Failure`**: `error` is <code>[RawError](grid_window_flex_pay_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Webhooks

> Source: [Webhooks](grid_window_flex_pay_api/apis/webhooks.py)

<details>
<summary><code>def paypal_webhook(body: Any, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, PaypalWebhookErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Verifies the PayPal signature against the unaltered body, then re-reads provider state. A webhook alone never marks a payment captured or voided.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.webhooks.with_raw_response.paypal_webhook({})
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type PaypalWebhookErrorBody
```

**Async**

```python
result = await async_client.webhooks.with_raw_response.paypal_webhook({})
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type PaypalWebhookErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>Any</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](grid_window_flex_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](grid_window_flex_pay_api/core/results.py)&#91;None, [PaypalWebhookErrorBody](grid_window_flex_pay_api/errors/paypal_webhook_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[PaypalWebhookErrorBody](grid_window_flex_pay_api/errors/paypal_webhook_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400 | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](grid_window_flex_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

